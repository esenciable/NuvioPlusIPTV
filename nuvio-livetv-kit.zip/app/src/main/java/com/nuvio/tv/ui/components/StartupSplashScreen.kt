package com.nuvio.tv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuvio.tv.ui.theme.brandWordmarkResource
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.nuvio.tv.R
import com.nuvio.tv.ui.theme.NuvioPrimitives
import com.nuvio.tv.ui.theme.NuvioTheme

@Composable
fun StartupSplashScreen(
    profileColorHex: String?,
    profileBackgroundUrl: String?,
    backgroundCacheKey: String? = null,
    skipGradient: Boolean = false,
    brandWordmarkRes: Int? = null,
    modifier: Modifier = Modifier
) {
    val avatarColor = remember(profileColorHex) {
        profileColorHex?.let {
            runCatching { Color(android.graphics.Color.parseColor(it)) }.getOrNull()
        } ?: NuvioPrimitives.blue500
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        if (!profileBackgroundUrl.isNullOrBlank()) {
            val imageData: Any = if (profileBackgroundUrl.startsWith("file:")) {
                java.io.File(java.net.URI(profileBackgroundUrl))
            } else {
                profileBackgroundUrl
            }
            val request = ImageRequest.Builder(LocalContext.current)
                .data(imageData)
                .crossfade(false)
            if (backgroundCacheKey != null) {
                request.memoryCacheKey(backgroundCacheKey)
                    .diskCacheKey(backgroundCacheKey)
                    .placeholderMemoryCacheKey(backgroundCacheKey)
            }
            AsyncImage(
                model = request.build(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (!skipGradient) {
            val baseBg = Color(0xFF121212)
            val baseBgElevated = NuvioPrimitives.neutral875
            val gradientTop = lerp(baseBgElevated, avatarColor, 0.3f)
            val gradientMid = lerp(baseBg, avatarColor, 0.14f)
            val halfFadeStrong = avatarColor.copy(alpha = 0.26f)
            val halfFadeSoft = avatarColor.copy(alpha = 0.08f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
                    .background(
                        brush = Brush.verticalGradient(
                            colorStops = arrayOf(
                                0f to gradientTop,
                                0.42f to gradientMid,
                                1f to baseBg
                            )
                        )
                    )
                    .background(
                        brush = Brush.horizontalGradient(
                            colorStops = arrayOf(
                                0f to halfFadeStrong,
                                0.45f to halfFadeSoft,
                                0.72f to Color.Transparent,
                                1f to Color.Transparent
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Live TV fork: "Nuvio + IPTV" logo (in the theme's colors) and what the app does.
            BrandWordmark(
                modifier = Modifier.height(48.dp),
                contentDescription = com.nuvio.tv.livetv.branding.LiveTvBranding.APP_NAME,
                drawableOverride = com.nuvio.tv.livetv.branding.LiveTvBranding.iptvWordmark(
                    brandWordmarkRes ?: NuvioTheme.currentTheme.brandWordmarkResource
                )
            )
            androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(14.dp))
            androidx.tv.material3.Text(
                text = com.nuvio.tv.livetv.branding.LiveTvBranding.TAGLINE,
                color = Color(0xFFC8CDD7).copy(alpha = 0.85f),
                fontSize = 16.sp
            )
            // Clear room between the tagline and the loading circle (they never overlap: they're
            // stacked, and this gap keeps them visually apart too).
            Spacer(modifier = Modifier.height(56.dp))
            LoadingIndicator(modifier = Modifier.size(NuvioTheme.spacing.xxxl))
        }
    }
}
