package com.nuvio.tv.livetv.data

import android.content.Context
import android.util.Log
import com.nuvio.tv.livetv.model.EpgAssignment
import com.nuvio.tv.livetv.model.EpgChannelEntry
import com.nuvio.tv.livetv.model.EpgProgram
import com.nuvio.tv.livetv.model.EpgSourceChannels
import com.nuvio.tv.livetv.model.EpgSource
import com.nuvio.tv.livetv.model.LiveChannel
import com.nuvio.tv.livetv.model.LiveTvLoadReport as LIVE_REPORT
import com.nuvio.tv.livetv.model.CatchupInfo
import com.nuvio.tv.livetv.model.LiveTvSettings
import com.nuvio.tv.livetv.model.PlaylistSource
import com.nuvio.tv.livetv.model.PlaylistAccount
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import javax.inject.Inject
import javax.inject.Singleton

data class LiveTvStatus(
    val loading: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val loadedOnce: Boolean = false,
    /** Busy, but nothing worth announcing (reading the saved channels at start-up). */
    val quiet: Boolean = false
)

@Singleton
class LiveTvRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val prefs: LiveTvPreferences,
    private val guideDb: EpgDatabase
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        // A provider that trickles data forever would otherwise hold up every other update
        // (deleting a playlist, turning one off) until the app is restarted.
        .callTimeout(10, TimeUnit.MINUTES)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private val baseDir = File(context.filesDir, "livetv")
    private val playlistDir = File(baseDir, "playlists")
    private val epgDir = File(baseDir, "epg")

    private val _channels = MutableStateFlow<List<LiveChannel>>(emptyList())
    val channels: StateFlow<List<LiveChannel>> = _channels.asStateFlow()

    /** Programs keyed by [LiveChannel.key], sorted by start. Offset is not applied here. */
    private val _programs = MutableStateFlow<Map<String, List<EpgProgram>>>(emptyMap())
    val programs: StateFlow<Map<String, List<EpgProgram>>> = _programs.asStateFlow()

    /** Channel key -> the guide channel picked automatically (shown in Assign EPG). */
    private val _autoMatches = MutableStateFlow<Map<String, EpgAssignment>>(emptyMap())
    val autoMatches: StateFlow<Map<String, EpgAssignment>> = _autoMatches.asStateFlow()

    /** Every loaded EPG source with its channel list (for "Change EPG"). */
    private val _epgSources = MutableStateFlow<List<EpgSourceChannels>>(emptyList())
    val epgSources: StateFlow<List<EpgSourceChannels>> = _epgSources.asStateFlow()

    private val _status = MutableStateFlow(LiveTvStatus())
    val status: StateFlow<LiveTvStatus> = _status.asStateFlow()

    private var initialized = false

    /** Loads cached data immediately, then refreshes anything older than the configured interval. */
    fun ensureLoaded(updateCheckDelayMs: Long = 0L) {
        if (initialized) return
        initialized = true
        scope.launch {
            // Saved channels and guide first: reading them only uses the device's storage.
            loadFromCache()
            // A playlist running out within a week: say so (once per app start).
            runCatching {
                val names = prefs.currentPlaylists().associate { it.id to it.name }
                prefs.playlistAccounts.first().forEach { (id, a) -> names[id]?.let { warnIfExpiring(id, it, a) } }
            }
            // Groups hidden or shown since the guide was stored (and from now on).
            watchHidden()
            // Space left empty in the guide database by earlier versions or updates.
            scheduleCompact()
            // Checking for playlist / guide updates uses the network and a lot of processing,
            // so when this starts with the app it waits a little, out of Nuvio's way.
            if (updateCheckDelayMs > 0) delay(updateCheckDelayMs)
            refreshStale()
        }
    }

    fun refreshAll(force: Boolean = true) {
        scope.launch { refreshInternal(forcePlaylists = force, forceEpg = force) }
    }

    /** After a restore from Google Drive: rebuild from the new sources, downloading what's missing. */
    /** After another TV's setup was applied: [changedPlaylists] get downloaded again straight away. */
    fun reloadAfterSync(changedPlaylists: Set<String> = emptySet()) {
        scope.launch {
            rebuild()
            refreshInternal(forcePlaylists = false, forceEpg = false, forceIds = changedPlaylists)
        }
    }

    fun refreshEpgOnly() {
        scope.launch { refreshInternal(forcePlaylists = false, forceEpg = true) }
    }

    private suspend fun refreshStale() = refreshInternal(forcePlaylists = false, forceEpg = false)

    // ---------------------------------------------------------------- sources CRUD

    suspend fun addPlaylist(name: String, url: String, userAgent: String = ""): String {
        val id = UUID.randomUUID().toString()
        prefs.updatePlaylists { it + PlaylistSource(id = id, name = name.ifBlank { "Playlist" }, url = url.trim(), userAgent = userAgent.trim()) }
        scope.launch { refreshInternal(forcePlaylists = false, forceEpg = false, forceIds = setOf(id)) }
        return id
    }

    suspend fun addXtream(
        name: String,
        server: String,
        username: String,
        password: String,
        importVod: Boolean = true,
        importLive: Boolean = true
    ): String {
        val id = UUID.randomUUID().toString()
        // Accept a pasted full link: keep just the server, and take the login from it if needed.
        val fromLink = PlaylistSource.credentialsFromLink(server)
        val user = username.trim().ifBlank { fromLink?.first.orEmpty() }
        val pass = password.trim().ifBlank { fromLink?.second.orEmpty() }
        prefs.updatePlaylists {
            it + PlaylistSource(
                id = id, name = name.ifBlank { "Xtream" }, url = "",
                xtreamServer = PlaylistSource.cleanXtreamServer(server),
                xtreamUsername = user, xtreamPassword = pass,
                importVod = importVod,
                importLive = importLive
            )
        }
        scope.launch { refreshInternal(forcePlaylists = false, forceEpg = false, forceIds = setOf(id)) }
        return id
    }

    suspend fun updatePlaylist(input: PlaylistSource) {
        val source = if (input.isXtream) {
            val fromLink = PlaylistSource.credentialsFromLink(input.xtreamServer)
            input.copy(
                xtreamServer = PlaylistSource.cleanXtreamServer(input.xtreamServer),
                xtreamUsername = input.xtreamUsername.trim().ifBlank { fromLink?.first.orEmpty() },
                xtreamPassword = input.xtreamPassword.trim().ifBlank { fromLink?.second.orEmpty() }
            )
        } else input
        val wasLive = prefs.currentPlaylists().firstOrNull { it.id == source.id }?.liveEnabled == true
        prefs.updatePlaylists { list -> list.map { if (it.id == source.id) source else it } }
        if (!source.liveEnabled) {
            // TV channels switched off (or never on, for an On Demand-only login): take them out
            // of the guide straight away and leave Live TV alone. Nothing to download for the
            // guide, so no "Loading Live TV" bubble; On Demand imports on its own.
            dropPlaylistNow(source.id)
            if (wasLive) scope.launch { rebuild() }
            return
        }
        scope.launch {
            rebuild()
            refreshInternal(forcePlaylists = false, forceEpg = false, forceIds = setOf(source.id))
        }
    }

    suspend fun removePlaylist(id: String) {
        prefs.updatePlaylists { list -> list.filterNot { it.id == id } }
        File(playlistDir, "$id.m3u").delete()
        embeddedEpgUrls.remove(id)
        dropPlaylistNow(id)
        scope.launch { rebuild() }
    }

    /**
     * Takes a deleted or turned-off playlist's channels out of the guide straight away, without
     * waiting for the full rebuild (which can be queued behind a long guide download).
     */
    private fun dropPlaylistNow(id: String) {
        val remaining = _channels.value.filterNot { it.sourceId == id }
        if (remaining.size == _channels.value.size) return
        val keys = remaining.mapTo(HashSet()) { it.key }
        _channels.value = remaining
        _programs.value = _programs.value.filterKeys { it in keys }
    }

    suspend fun setPlaylistEnabled(id: String, enabled: Boolean) {
        prefs.updatePlaylists { list -> list.map { if (it.id == id) it.copy(enabled = enabled) else it } }
        if (!enabled) dropPlaylistNow(id)
        // Rebuild from the cached files first (turning a playlist on or off downloads nothing,
        // so the refresh alone wouldn't rebuild the channel list), then fetch anything missing.
        scope.launch {
            rebuild()
            refreshInternal(forcePlaylists = false, forceEpg = false)
        }
    }

    suspend fun movePlaylist(id: String, delta: Int) {
        prefs.updatePlaylists { list ->
            val m = list.toMutableList()
            val i = m.indexOfFirst { it.id == id }
            if (i < 0) return@updatePlaylists list
            val item = m.removeAt(i)
            m.add((i + delta).coerceIn(0, m.size), item)
            m
        }
        scope.launch { rebuild() }
    }

    suspend fun addEpg(name: String, url: String): String {
        val id = UUID.randomUUID().toString()
        prefs.updateEpgSources { it + EpgSource(id = id, name = name.ifBlank { "EPG" }, url = url.trim()) }
        scope.launch { refreshInternal(forcePlaylists = false, forceEpg = false, forceIds = setOf(id)) }
        return id
    }

    suspend fun updateEpg(source: EpgSource) {
        prefs.updateEpgSources { list -> list.map { if (it.id == source.id) source else it } }
        scope.launch { refreshInternal(forcePlaylists = false, forceEpg = false, forceIds = setOf(source.id)) }
    }

    suspend fun removeEpg(id: String) {
        prefs.updateEpgSources { list -> list.filterNot { it.id == id } }
        File(epgDir, "$id.xml").delete()
        scope.launch { rebuild() }
    }

    suspend fun setEpgEnabled(id: String, enabled: Boolean) {
        prefs.updateEpgSources { list -> list.map { if (it.id == id) it.copy(enabled = enabled) else it } }
        scope.launch {
            rebuild()
            refreshInternal(forcePlaylists = false, forceEpg = false)
        }
    }

    // ---------------------------------------------------------------- core

    private suspend fun loadFromCache() {
        if (_epgLogos.value.isEmpty()) _epgLogos.value = withContext(Dispatchers.IO) { readEpgLogos() }
        mutex.withLock { rebuildLocked() }
    }

    // ---------------------------------------------------------------- logos from the guide

    private val epgLogosFile get() = File(baseDir, "epg_logos.json")
    private val _epgLogos = MutableStateFlow<Map<String, String>>(emptyMap())

    /** Channel key -> the logo its matched guide channel has (playlists can prefer these). */
    val epgLogos: StateFlow<Map<String, String>> = _epgLogos.asStateFlow()

    private fun readEpgLogos(): Map<String, String> = runCatching {
        val f = epgLogosFile
        if (!f.exists()) return@runCatching emptyMap<String, String>()
        val o = org.json.JSONObject(f.readText())
        val out = HashMap<String, String>(o.length())
        o.keys().forEach { k -> o.optString(k).takeIf { it.isNotBlank() }?.let { out[k] = it } }
        out
    }.getOrDefault(emptyMap())

    // ---- The guides' channel lists (Assign EPG), kept between app starts.
    private val sourceListsFile get() = File(baseDir, "epg_channel_lists.bin")

    /** Which guide files the saved lists came from (each file's size and contents stamp). */
    private fun sourceListsStamp(targets: List<EpgTarget>): String = targets.joinToString(",") { t ->
        val f = epgFile(t.fileId)
        t.fileId + ":" + f.length() + ":" + contentStamp(f)
    }

    private fun saveSourceLists(targets: List<EpgTarget>, lists: List<EpgSourceChannels>) {
        runCatching {
            val tmp = File(baseDir, sourceListsFile.name + ".tmp")
            java.io.DataOutputStream(java.io.BufferedOutputStream(java.util.zip.GZIPOutputStream(tmp.outputStream()))).use { out ->
                out.writeInt(SOURCE_LISTS_VERSION)
                out.writeUTF(sourceListsStamp(targets))
                out.writeInt(lists.size)
                lists.forEach { l ->
                    out.writeUTF(l.sourceId); out.writeUTF(l.name); out.writeUTF(l.label)
                    out.writeInt(l.channels.size)
                    l.channels.forEach { e ->
                        out.writeUTF(e.id)
                        out.writeInt(e.names.size)
                        e.names.forEach { out.writeUTF(it.take(500)) }
                        out.writeUTF(e.icon.orEmpty().take(2000))
                    }
                }
            }
            if (!tmp.renameTo(sourceListsFile)) { tmp.copyTo(sourceListsFile, overwrite = true); tmp.delete() }
        }.onFailure { Log.w(TAG, "Couldn't save the guides' channel lists", it) }
    }

    /** Loads the saved lists if they still match the guide files; marks what's in use. */
    private suspend fun loadSourceLists(targets: List<EpgTarget>) {
        val f = sourceListsFile
        if (!f.exists()) {
            LIVE_REPORT.add("Assign EPG lists: none saved yet (read when Assign EPG is first opened)")
            return
        }
        val lists = runCatching {
            java.io.DataInputStream(java.io.BufferedInputStream(java.util.zip.GZIPInputStream(f.inputStream()))).use { input ->
                if (input.readInt() != SOURCE_LISTS_VERSION) return@use null
                if (input.readUTF() != sourceListsStamp(targets)) return@use null
                val n = input.readInt()
                (0 until n).map {
                    val sourceId = input.readUTF(); val name = input.readUTF(); val label = input.readUTF()
                    val count = input.readInt()
                    val entries = ArrayList<EpgChannelEntry>(count)
                    repeat(count) {
                        val id = input.readUTF()
                        val names = (0 until input.readInt()).map { input.readUTF() }
                        val icon = input.readUTF().ifBlank { null }
                        entries += EpgChannelEntry(id, names, icon)
                    }
                    EpgSourceChannels(sourceId, name, label, entries)
                }
            }
        }.onFailure { Log.w(TAG, "Couldn't read the guides' channel lists", it) }.getOrNull()
        if (lists == null) {
            LIVE_REPORT.add("Assign EPG lists: saved copy out of date (read when Assign EPG is first opened)")
            return
        }
        // Which guide channels already feed a playlist channel (matched or assigned).
        val overrides = prefs.userState.first().epgOverrides
        val used = HashMap<String, MutableSet<String>>()
        (_autoMatches.value.values + overrides.values).forEach { used.getOrPut(it.sourceId) { HashSet() } += it.xmltvId }
        // Only if nothing filled them in the meantime (a guide update in progress wins).
        if (_epgSources.value.isEmpty()) {
            _epgSources.value = lists.map { it.copy(usedIds = used[it.sourceId].orEmpty()) }
            LIVE_REPORT.add("Assign EPG lists: ${lists.size} guide(s) ready from last time")
        }
    }

    /** Stops reading a guide once its channel list has been read (the programmes aren't needed). */
    private class ChannelListRead(val channels: Map<String, XmltvChannel>) : RuntimeException()

    private val _epgListsLoading = MutableStateFlow(false)
    /** Assign EPG's channel lists are being read (see [ensureSourceLists]). */
    val epgListsLoading: StateFlow<Boolean> = _epgListsLoading.asStateFlow()

    /**
     * Assign EPG opened with no channel lists (no saved copy yet, e.g. the first time after
     * updating, or the guides changed without being read since): reads just each guide's
     * channel list, the short part at the top of the file. No programmes, and nothing at
     * start-up: only when Assign EPG actually needs them.
     */
    fun ensureSourceLists() {
        if (_epgSources.value.isNotEmpty() || _epgListsLoading.value) return
        _epgListsLoading.value = true
        scope.launch(Dispatchers.IO) {
            try {
                readSourceLists(collectEpgTargets())
            } finally {
                _epgListsLoading.value = false
            }
        }
    }

    private suspend fun readSourceLists(targets: List<EpgTarget>) {
        if (_epgSources.value.isNotEmpty()) return
        val lists = ArrayList<EpgSourceChannels>()
        for (t in targets) {
            val file = epgFile(t.fileId)
            if (!file.exists()) continue
            val channels: Map<String, XmltvChannel> = try {
                openMaybeGzip(file).use { input ->
                    XmltvParser.parse(input, 0L, 0L) { xc -> throw ChannelListRead(LinkedHashMap(xc)) }
                }
                emptyMap()
            } catch (e: ChannelListRead) {
                e.channels
            } catch (e: Exception) {
                Log.w(TAG, "Couldn't read the channel list of ${t.name}", e)
                emptyMap()
            }
            val label = runCatching { java.net.URI(t.url).host?.removePrefix("www.") }.getOrNull()
                ?.takeIf { it.isNotBlank() } ?: t.name
            lists += EpgSourceChannels(
                t.fileId, t.name, label,
                channels.values.map { EpgChannelEntry(it.id, it.displayNames, it.icon) }.sortedBy { it.displayName.lowercase() }
            )
        }
        if (lists.isEmpty()) return
        val overrides = prefs.userState.first().epgOverrides
        val used = HashMap<String, MutableSet<String>>()
        (_autoMatches.value.values + overrides.values).forEach { used.getOrPut(it.sourceId) { HashSet() } += it.xmltvId }
        if (_epgSources.value.isEmpty()) {
            _epgSources.value = lists.map { it.copy(usedIds = used[it.sourceId].orEmpty()) }
            saveSourceLists(targets, lists)
            LIVE_REPORT.add("Assign EPG lists: ${lists.size} guide(s) read for Assign EPG")
        }
    }

    private fun saveEpgLogos(map: Map<String, String>) {
        runCatching {
            val o = org.json.JSONObject()
            map.forEach { (k, v) -> o.put(k, v) }
            baseDir.mkdirs()
            epgLogosFile.writeText(o.toString())
        }
    }

    /** "Prefer logos from playlist / EPG" for one playlist: only the logos change, nothing reloads. */
    suspend fun setPlaylistLogoSource(id: String, logoSource: String) {
        prefs.updatePlaylists { list -> list.map { if (it.id == id) it.copy(logoSource = logoSource) else it } }
    }

    private suspend fun rebuild() {
        mutex.withLock { rebuildLocked() }
    }

    private suspend fun refreshInternal(
        forcePlaylists: Boolean,
        forceEpg: Boolean,
        forceIds: Set<String> = emptySet()
    ) = mutex.withLock {
        val settings = prefs.currentSettings()
        val now = System.currentTimeMillis()
        val playlists = prefs.currentPlaylists().filter { it.liveEnabled }
        var changed = false
        // Automatic checks wait while a movie or episode is playing in Nuvio's player.
        val automatic = !forcePlaylists && !forceEpg && forceIds.isEmpty()
        suspend fun outOfTheWay() { if (automatic) BackgroundWork.awaitIdle() }

        for (pl in playlists) {
            outOfTheWay()
            val file = playlistFile(pl.id)
            val stale = !file.exists() ||
                now - file.lastModified() > settings.playlistRefreshHours.coerceAtLeast(1) * HOUR
            if (forcePlaylists || stale || pl.id in forceIds) {
                LIVE_REPORT.add("Checking playlist \"${pl.name}\" for updates")
                setStatus(loading = true, message = "Updating playlist \"${pl.name}\"…")
                val before = if (file.exists()) file.length() to file.lastModified() else null
                val result = runCatching {
                    if (pl.isXtream) {
                        val old = if (file.exists()) File(file.parentFile, file.name + ".prev").also { file.copyTo(it, overwrite = true) } else null
                        downloadXtream(pl, file)
                        // Xtream lists are rebuilt each time: unchanged if identical to before.
                        val unchanged = old != null && old.length() == file.length() && sameContent(old, file)
                        old?.delete()
                        if (!unchanged) markChanged(file)
                        LIVE_REPORT.add(if (unchanged) "Playlist \"${pl.name}\": no changes" else "Playlist \"${pl.name}\": new content")
                        !unchanged
                    } else download(pl.resolvedUrl(), file, pl.userAgent, progressLabel = "Downloading playlist \"${pl.name}\"")
                }
                // M3U links from Xtream providers (get.php with a login): the account's details.
                if (!pl.isXtream) refreshM3uAccount(pl)
                val err = result.exceptionOrNull()?.let { e ->
                    when (e) {
                        is java.net.UnknownHostException -> "Couldn't find the provider's server (${e.message?.substringAfter("\"")?.substringBefore("\"") ?: "address"}). Check the address, your internet, or try again later."
                        is java.net.SocketTimeoutException -> "The provider took too long to answer (timeout). It may be busy; try again later."
                        else -> e.message ?: e.javaClass.simpleName
                    }
                }
                prefs.updatePlaylists { list ->
                    list.map {
                        if (it.id == pl.id) it.copy(lastUpdatedMs = if (err == null) now else it.lastUpdatedMs, lastError = err) else it
                    }
                }
                if (err != null) {
                    Log.w(TAG, "Playlist ${pl.name} failed: $err")
                    LIVE_REPORT.add("Playlist \"${pl.name}\" failed: $err" + if (pl.isXtream) " (Xtream login: server ${if (pl.xtreamServer.isBlank()) "missing" else "set"}, user ${if (pl.xtreamUsername.isBlank()) "missing" else "set"}, password ${if (pl.xtreamPassword.isBlank()) "missing" else "set"})" else "")
                }
                if (result.getOrNull() == true || (before == null && file.exists())) changed = true
            }
        }

        // Build channels first so EPG matching knows which channels exist.
        if (changed || _channels.value.isEmpty()) {
            outOfTheWay()
            setStatus(loading = true, message = "Reading channels…")
            buildChannels()
            saveChannels() // so the next start uses it straight away
        }

        val epgTargets = collectEpgTargets()
        // Files saved by earlier versions, unzipped: zipped once (see download()).
        (epgTargets.map { epgFile(it.fileId) } + playlists.map { playlistFile(it.id) }).forEach { zipInPlace(it) }
        for (target in epgTargets) {
            outOfTheWay()
            val file = epgFile(target.fileId)
            val stale = !file.exists() ||
                now - file.lastModified() > settings.epgRefreshHours.coerceAtLeast(1) * HOUR
            if (forceEpg || stale || target.sourceId in forceIds || (target.sourceId == null && changed && !file.exists())) {
                setStatus(loading = true, message = "Downloading guide \"${target.name}\"…")
                val result = runCatching { download(target.url, file, target.userAgent, progressLabel = "Downloading guide \"${target.name}\"") }
                if (result.getOrNull() == true) changed = true
                val err = result.exceptionOrNull()?.let { it.message ?: it.javaClass.simpleName }
                if (target.sourceId != null) {
                    prefs.updateEpgSources { list ->
                        list.map { if (it.id == target.sourceId) it.copy(lastUpdatedMs = if (err == null) now else it.lastUpdatedMs, lastError = err) else it }
                    }
                }
                if (err != null) {
                    Log.w(TAG, "EPG ${target.name} failed: $err")
                    LIVE_REPORT.add("Guide \"${target.name}\" failed: $err")
                }
            }
        }

        if (changed || _programs.value.isEmpty()) {
            outOfTheWay()
            setStatus(loading = true, message = "Matching guide data…")
            buildPrograms(settings, epgTargets)
        }
        _status.value = LiveTvStatus(loading = false, loadedOnce = true)
    }

    private suspend fun rebuildLocked() {
        // Reading the saved channels and guide takes a second or two and changes nothing, so no
        // "Loading channels…" bubble for it (people took it for a full reload every time). The
        // bubble only shows if the playlists really have to be read again.
        setStatus(loading = true, message = null, quiet = true)
        // The channel list as it was last read, when no playlist has changed since: Live TV
        // (Favorites included) appears straight away instead of re-reading every playlist file.
        var t0 = System.currentTimeMillis()
        // The stored guide is read at the same time as the channel list (it only has to be
        // checked against the channels afterwards), so the two waits overlap.
        val guidePreRead = scope.async(Dispatchers.IO) { preReadGuide() }
        if (!loadSavedChannels()) {
            setStatus(loading = true, message = "Loading channels…")
            buildChannels()
            saveChannels()
            LIVE_REPORT.add("Channels re-read from playlists: ${_channels.value.size} in ${System.currentTimeMillis() - t0} ms")
        } else {
            LIVE_REPORT.add("Saved channel list used: ${_channels.value.size} channels in ${System.currentTimeMillis() - t0} ms")
        }
        val targets = collectEpgTargets()
        val settings = prefs.currentSettings()
        // The guide as it was last matched, if nothing it depends on has changed: the guide
        // fills in straight away instead of re-reading every guide file at each start.
        t0 = System.currentTimeMillis()
        if (!loadGuideFromDb(settings, targets, guidePreRead.await())) {
            buildPrograms(settings, targets)
            LIVE_REPORT.add("Guide re-read from guide files in ${System.currentTimeMillis() - t0} ms")
        } else {
            LIVE_REPORT.add("Stored guide used: ${_programs.value.size} channels with listings in ${System.currentTimeMillis() - t0} ms")
        }
        _status.value = LiveTvStatus(loading = false, loadedOnce = true)
    }

    /** Which parts of a saved copy's fingerprint differ (for the start-up report). */
    private fun fingerprintDiff(old: String, new: String): String {
        val a = old.split('|', ',').toSet()
        val b = new.split('|', ',').toSet()
        val changed = (b - a).take(4).joinToString("; ") { it.take(60) }
        return if (changed.isBlank()) "format changed" else "changed: $changed"
    }

    // ---------------------------------------------------------------- saved channel list

    private val savedChannelsFile get() = File(baseDir, "channels_cache3.bin")

    /** Everything the channel list is built from; a different value means it must be re-read. */
    private suspend fun channelsFingerprint(): String {
        val sb = StringBuilder().append(CHANNELS_CACHE_VERSION).append('|')
        prefs.currentPlaylists().filter { it.liveEnabled }.forEach { pl ->
            val f = playlistFile(pl.id)
            sb.append(pl.id).append(':').append(pl.name.hashCode()).append(':').append(pl.userAgent.hashCode())
                .append(':').append(f.length()).append(':').append(contentStamp(f)).append(',')
        }
        return sb.toString()
    }

    /**
     * Saved channel list, format 3: not zipped (unzipping cost more than reading a slightly
     * bigger file on TV boxes), and text that repeats across channels (playlist, group,
     * catch-up type) stored once and referred to by number. Faster to read, less memory.
     */
    private suspend fun loadSavedChannels(): Boolean = withContext(Dispatchers.IO) {
        runCatching { File(baseDir, "channels_cache.bin").delete() } // the old zipped format
        val file = savedChannelsFile
        if (!file.exists()) return@withContext false
        val expected = channelsFingerprint()
        runCatching {
            java.io.DataInputStream(java.io.BufferedInputStream(file.inputStream(), 256 * 1024)).use { input ->
                val stored = input.readUTF()
                if (stored != expected) {
                    LIVE_REPORT.add("Saved channel list out of date: ${fingerprintDiff(stored, expected)}")
                    return@withContext false
                }
                val epg = HashMap<String, List<String>>()
                repeat(input.readInt()) {
                    val id = input.readUTF()
                    epg[id] = List(input.readInt()) { input.readUTF() }
                }
                val table = Array(input.readInt()) { input.readUTF() }
                fun shared(): String = table[input.readInt()]
                fun opt(): String? = if (input.readBoolean()) input.readUTF() else null
                val count = input.readInt()
                val list = ArrayList<LiveChannel>(count)
                repeat(count) {
                    val key = input.readUTF()
                    val sourceId = shared()
                    val sourceName = shared()
                    val name = input.readUTF()
                    val tvgId = opt()
                    val tvgName = opt()
                    val logo = opt()
                    val groupId = shared()
                    val group = shared()
                    val number = input.readInt()
                    val url = input.readUTF()
                    val headerCount = input.readInt()
                    val headers: Map<String, String> = if (headerCount == 0) emptyMap()
                    else HashMap<String, String>(headerCount * 2).apply { repeat(headerCount) { put(shared(), input.readUTF()) } }
                    val catchup = if (input.readBoolean()) CatchupInfo(shared(), opt(), input.readInt(), input.readDouble()) else null
                    val drm = if (input.readBoolean()) {
                        val scheme = shared()
                        val license = input.readUTF()
                        val lh = HashMap<String, String>().apply { repeat(input.readInt()) { put(input.readUTF(), input.readUTF()) } }
                        com.nuvio.tv.livetv.model.DrmInfo(scheme, license, lh, opt())
                    } else null
                    list += LiveChannel(key, sourceId, sourceName, name, tvgId, tvgName, logo, groupId, group, number, url, headers, catchup, drm)
                }
                embeddedEpgUrls.clear()
                embeddedEpgUrls.putAll(epg)
                _channels.value = list
                true
            }
        }.getOrElse {
            Log.w(TAG, "Saved channel list unreadable", it)
            false
        }
    }

    private suspend fun saveChannels() = withContext(Dispatchers.IO) {
        val fingerprint = channelsFingerprint()
        runCatching {
            val list = _channels.value
            // Text shared by many channels, stored once.
            val index = LinkedHashMap<String, Int>()
            fun id(v: String): Int = index.getOrPut(v) { index.size }
            list.forEach { c ->
                id(c.sourceId); id(c.sourceName); id(c.groupId); id(c.group)
                c.headers.keys.forEach { id(it) }
                c.catchup?.let { id(it.type) }
                c.drm?.let { id(it.scheme) }
            }
            val tmp = File(baseDir, "channels_cache3.tmp")
            java.io.DataOutputStream(java.io.BufferedOutputStream(tmp.outputStream(), 256 * 1024)).use { out ->
                fun opt(v: String?) { out.writeBoolean(v != null); if (v != null) out.writeUTF(v) }
                out.writeUTF(fingerprint)
                out.writeInt(embeddedEpgUrls.size)
                embeddedEpgUrls.forEach { (eid, urls) -> out.writeUTF(eid); out.writeInt(urls.size); urls.forEach { out.writeUTF(it) } }
                out.writeInt(index.size)
                index.keys.forEach { out.writeUTF(it) }
                out.writeInt(list.size)
                list.forEach { c ->
                    out.writeUTF(c.key)
                    out.writeInt(index.getValue(c.sourceId)); out.writeInt(index.getValue(c.sourceName))
                    out.writeUTF(c.name)
                    opt(c.tvgId); opt(c.tvgName); opt(c.logo)
                    out.writeInt(index.getValue(c.groupId)); out.writeInt(index.getValue(c.group))
                    out.writeInt(c.number)
                    out.writeUTF(c.url)
                    out.writeInt(c.headers.size)
                    c.headers.forEach { (k, v) -> out.writeInt(index.getValue(k)); out.writeUTF(v) }
                    out.writeBoolean(c.catchup != null)
                    c.catchup?.let { cu -> out.writeInt(index.getValue(cu.type)); opt(cu.source); out.writeInt(cu.days); out.writeDouble(cu.correctionHours) }
                    out.writeBoolean(c.drm != null)
                    c.drm?.let { d ->
                        out.writeInt(index.getValue(d.scheme)); out.writeUTF(d.license)
                        out.writeInt(d.licenseHeaders.size); d.licenseHeaders.forEach { (k, v) -> out.writeUTF(k); out.writeUTF(v) }
                        opt(d.manifestType)
                    }
                }
            }
            if (!tmp.renameTo(savedChannelsFile)) { tmp.copyTo(savedChannelsFile, overwrite = true); tmp.delete() }
        }.onFailure { Log.w(TAG, "Couldn't save the channel list", it) }
    }

    // ---------------------------------------------------------------- saved guide

    /** Assign EPG needs the full guide-channel lists, which the saved guide skips. */
    @Volatile private var epgDetailsPending = false

    // ---------------------------------------------------------------- hidden channels

    /** The channels the stored guide left out (hidden in every profile), as last stored. */
    private val skippedFile get() = File(baseDir, "guide_skipped.txt")
    @Volatile private var guideSkipped: Set<String>? = null

    private fun saveSkipped(keys: Set<String>) {
        guideSkipped = keys
        runCatching {
            val tmp = File(baseDir, skippedFile.name + ".tmp")
            java.io.DataOutputStream(java.io.BufferedOutputStream(java.util.zip.GZIPOutputStream(tmp.outputStream()))).use { out ->
                out.writeInt(keys.size)
                keys.forEach { out.writeUTF(it) }
            }
            if (!tmp.renameTo(skippedFile)) { tmp.copyTo(skippedFile, overwrite = true); tmp.delete() }
        }
    }

    /** Null for a guide stored before channels were left out (it has everything). */
    private fun loadSkipped(): Set<String>? = guideSkipped ?: runCatching {
        if (!skippedFile.exists()) return@runCatching null
        java.io.DataInputStream(java.io.BufferedInputStream(java.util.zip.GZIPInputStream(skippedFile.inputStream()))).use { input ->
            HashSet<String>().apply { repeat(input.readInt()) { add(input.readUTF()) } }
        }
    }.getOrNull()?.also { guideSkipped = it }

    private var hiddenWatch: kotlinx.coroutines.Job? = null

    /** Follows hiding and showing groups and channels (in any profile) once the guide is loaded. */
    private fun watchHidden() {
        if (hiddenWatch != null) return
        hiddenWatch = scope.launch {
            prefs.hiddenEverywhere.collectLatest {
                delay(2_000) // a few changes in a row are handled together
                // Once started, finished (a newer change waits its turn instead of cutting it short).
                withContext(kotlinx.coroutines.NonCancellable) { mutex.withLock { syncHidden() } }
            }
        }
    }

    /**
     * Keeps the stored guide in step with what's hidden everywhere:
     *  - newly hidden channels: their listings are deleted (nothing is read);
     *  - channels shown again: the guide is read from the saved guide files, so they get listings.
     */
    private suspend fun syncHidden() = withContext(Dispatchers.IO) {
        if (!guideInDb) return@withContext
        val channels = _channels.value
        if (channels.isEmpty()) return@withContext
        val hidden = prefs.currentHiddenEverywhere()
        val nowHidden = channels.filter { hidden.hides(it.key, it.groupId) }.mapTo(HashSet()) { it.key }
        val skipped = loadSkipped() ?: emptySet() // older guides stored every channel
        val keys = channels.mapTo(HashSet()) { it.key }
        val shownAgain = skipped.filter { it in keys && it !in nowHidden }
        if (shownAgain.isNotEmpty()) {
            LIVE_REPORT.add("Guide: ${shownAgain.size} channels shown again, reading their listings")
            setStatus(loading = true, message = "Updating guide…")
            buildPrograms(prefs.currentSettings(), collectEpgTargets())
            _status.value = LiveTvStatus(loading = false, loadedOnce = true)
            return@withContext
        }
        val newlyHidden = nowHidden - skipped
        if (newlyHidden.isEmpty()) return@withContext
        runCatching { guideDb.deleteChannels(newlyHidden) }.onFailure { Log.w(TAG, "Couldn't drop hidden listings", it) }
        _programs.value = _programs.value - newlyHidden
        saveSkipped(skipped.filterTo(HashSet()) { it in keys } + newlyHidden)
        scheduleCompact()
    }

    private var compactJob: kotlinx.coroutines.Job? = null

    /** Gives the guide database's empty space back, a little after a big change, out of the way. */
    private fun scheduleCompact() {
        compactJob?.cancel()
        compactJob = scope.launch {
            delay(30_000)
            BackgroundWork.awaitIdle()
            mutex.withLock { withContext(Dispatchers.IO) { guideDb.compact() } }
        }
    }

    /** Builds the full guide details (for Assign EPG) if the saved guide was used. */
    fun ensureEpgDetails() {
        if (!epgDetailsPending) return
        epgDetailsPending = false
        scope.launch {
            mutex.withLock { buildPrograms(prefs.currentSettings(), collectEpgTargets()) }
        }
    }

    private val savedGuideFile get() = File(baseDir, "guide_cache.bin")

    // ---------------------------------------------------------------- guide database

    /** The time span currently loaded from the guide database (all of it if the database isn't used). */
    @Volatile private var loadedFrom = Long.MAX_VALUE
    @Volatile private var loadedTo = Long.MIN_VALUE
    @Volatile private var guideInDb = false
    private val rangeMutex = Mutex()

    private fun defaultWindow(now: Long = System.currentTimeMillis()) = (now - 3 * HOUR) to (now + 12 * HOUR + RANGE_SLACK_MS)

    /**
     * Opening Live TV: if the guide database matches the current guide and channels, read just
     * the hours around now. Instant, however big the guide is.
     */
    /** What [preReadGuide] read ahead: the stored fingerprint, and the priority channels' listings. */
    private class GuidePreRead(val fingerprint: String?, val from: Long, val to: Long, val window: Map<String, List<EpgProgram>>)

    /** Channels to fill in first: the group you were last looking at, and your Favorites. */
    private val priorityFile get() = File(baseDir, "guide_priority.txt")

    private fun priorityKeys(): List<String> =
        runCatching { priorityFile.readLines().filter { it.isNotBlank() } }.getOrDefault(emptyList())

    /** Loads these channels' listings straight away if they aren't loaded yet (the group you open). */
    fun loadChannelsNow(keys: List<String>) {
        if (!guideInDb || keys.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            val missing = keys.distinct().filter { it !in _programs.value }
            if (missing.isEmpty()) return@launch
            val got = runCatching { guideDb.range(loadedFrom, loadedTo, light = true, channels = missing) }.getOrNull() ?: return@launch
            rangeMutex.withLock {
                val cur = _programs.value
                _programs.value = cur + got.filterKeys { it !in cur }
            }
        }
    }

    /** Remembers which channels to load first next time, and loads them now if needed. */
    fun rememberPriority(keys: List<String>) {
        val list = keys.distinct().take(600)
        if (list.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            runCatching { priorityFile.writeText(list.joinToString("\n")) }
            if (!guideInDb) return@launch
            val missing = list.filter { it !in _programs.value }
            if (missing.isEmpty()) return@launch
            val got = runCatching { guideDb.range(loadedFrom, loadedTo, light = true, channels = missing) }.getOrNull() ?: return@launch
            rangeMutex.withLock { _programs.value = _programs.value + got }
        }
    }

    private fun preReadGuide(): GuidePreRead? = runCatching {
        val now = System.currentTimeMillis()
        val from = now - 60 * 60 * 1000L
        val to = now + 4 * HOUR
        val fp = guideDb.fingerprint() ?: return@runCatching null
        val keys = priorityKeys()
        val window = if (keys.isEmpty()) emptyMap() else guideDb.range(from, to, light = true, channels = keys)
        GuidePreRead(fp, from, to, window)
    }.getOrNull()

    /**
     * Opening Live TV: if the guide database matches the current guide and channels, show the
     * channels you were last looking at straight away (read ahead, short form), then fill in all
     * the others in the background. Instant, however big the guide is.
     */
    private suspend fun loadGuideFromDb(settings: LiveTvSettings, targets: List<EpgTarget>, pre: GuidePreRead?): Boolean = withContext(Dispatchers.IO) {
        if (_channels.value.isEmpty()) return@withContext false
        runCatching { savedGuideFile.delete() } // the old single-file copy isn't used any more
        val expected = guideFingerprint(settings, targets)
        val stored = pre?.fingerprint ?: runCatching { guideDb.fingerprint() }.getOrNull()
        if (stored != expected) {
            LIVE_REPORT.add(if (stored == null) "No stored guide yet" else "Stored guide out of date: ${fingerprintDiff(stored, expected)}")
            return@withContext false
        }
        val now = System.currentTimeMillis()
        val from = pre?.from ?: (now - 60 * 60 * 1000L)
        val to = pre?.to ?: (now + 4 * HOUR)
        _programs.value = pre?.window.orEmpty()
        fullRangeChannels.clear()
        _autoMatches.value = runCatching { guideDb.autoMatches() }.getOrDefault(emptyMap())
        loadedFrom = from
        loadedTo = to
        guideInDb = true
        lightPrograms = true
        epgDetailsPending = true
        // The guides' channel lists (for Assign EPG), saved last time the guides were read, so
        // they're ready without a Full Scan.
        if (_epgSources.value.isEmpty()) scope.launch(Dispatchers.IO) { loadSourceLists(targets) }
        LIVE_REPORT.add("First channels' listings ready: ${_programs.value.size} channels")
        // Everything else (short form, the usual hours), in the background, in one read.
        rangeBusy.set(true)
        scope.launch(Dispatchers.IO) {
          try {
            val t0 = System.currentTimeMillis()
            val (fullFrom, fullTo) = defaultWindow()
            val rest = runCatching { guideDb.range(fullFrom, fullTo, light = true) }.getOrNull()
            if (rest != null) rangeMutex.withLock {
                val merged = HashMap<String, List<EpgProgram>>(rest)
                _programs.value.forEach { (k, v) -> if ((merged[k]?.size ?: 0) < v.size) merged[k] = v }
                _programs.value = merged
                loadedFrom = minOf(loadedFrom, fullFrom)
                loadedTo = maxOf(loadedTo, fullTo)
            }
            LIVE_REPORT.add("All channels' listings ready: ${_programs.value.size} channels in ${System.currentTimeMillis() - t0} ms")
          } finally {
            rangeBusy.set(false)
            pendingRange?.let { (f, t) -> pendingRange = null; ensureRange(f, t) }
          }
        }
        true
    }

    /** Programs in memory may be the short form (no descriptions): see [programDetails]. */
    @Volatile var lightPrograms = false
        private set

    /** One show's full details (description, cast…), from the stored guide. */
    suspend fun programDetails(channelKey: String, startMs: Long): EpgProgram? = withContext(Dispatchers.IO) {
        if (!guideInDb) null else runCatching { guideDb.program(channelKey, startMs) }.getOrNull()
    }

    /**
     * Makes sure listings for [fromMs]..[toMs] are loaded (scrolling the guide ahead or back,
     * catch-up). Reads only what's missing; does nothing when the database isn't in use.
     */
    /** A big read is running: further requests wait for it instead of starting another. */
    private val rangeBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var pendingRange: Pair<Long, Long>? = null

    fun ensureRange(fromMs: Long, toMs: Long) {
        if (!guideInDb || (fromMs >= loadedFrom && toMs <= loadedTo)) return
        if (!rangeBusy.compareAndSet(false, true)) {
            // One read at a time (each covers every channel): remember the widest request.
            val p = pendingRange
            pendingRange = if (p == null) fromMs to toMs else minOf(p.first, fromMs) to maxOf(p.second, toMs)
            return
        }
        scope.launch(Dispatchers.IO) {
          try {
            // Read without holding the lock (a big read used to make everything else wait for it,
            // like a group you just opened); only the merge is locked.
            val from = minOf(fromMs, loadedFrom)
            // A few hours extra ahead: the guide asks for "12 hours from now" every 30 seconds,
            // and without slack each ask went past what was loaded by 30 seconds.
            val to = maxOf(toMs + RANGE_SLACK_MS, loadedTo)
            // Only the hours not loaded yet. It used to read everything from the earliest hour
            // loaded to the latest again, for every channel, each time the guide was scrolled
            // further ahead: the further you went, the longer each read took, so new listings
            // took up to a minute to appear at the end of what was shown.
            val haveSome = loadedFrom != Long.MAX_VALUE && loadedTo != Long.MIN_VALUE && loadedFrom < loadedTo
            val parts = if (!haveSome || to <= loadedFrom || from >= loadedTo) listOf(from to to)
            else buildList {
                if (from < loadedFrom) add(from to loadedFrom)
                if (to > loadedTo) add(loadedTo to to)
            }
            val reads = parts.map { (f, t) ->
                runCatching { guideDb.range(f, t, light = lightPrograms) }.getOrNull() ?: return@launch
            }
            rangeMutex.withLock {
                if (fromMs >= loadedFrom && toMs <= loadedTo) return@withLock
                val merged = HashMap(_programs.value)
                reads.forEach { got ->
                    got.forEach { (ch, list) ->
                        val cur = merged[ch]
                        merged[ch] = if (cur.isNullOrEmpty()) list else {
                            // Shows running across the edge come back in both reads: once each.
                            val starts = cur.mapTo(HashSet()) { it.startMs }
                            val extra = list.filter { it.startMs !in starts }
                            if (extra.isEmpty()) cur else (cur + extra).sortedBy { it.startMs }
                        }
                    }
                }
                _programs.value = merged
                loadedFrom = minOf(from, loadedFrom)
                loadedTo = maxOf(to, loadedTo)
            }
          } finally {
            rangeBusy.set(false)
            pendingRange?.let { (f, t) -> pendingRange = null; ensureRange(f, t) }
          }
        }
    }

    // ---------------------------------------------------------------- a group's full guide

    /** Channels whose listings are loaded for the whole guide (as many days ahead as set). */
    private val fullRangeChannels = java.util.Collections.synchronizedSet(HashSet<String>())
    private var fullRangeJob: kotlinx.coroutines.Job? = null

    /**
     * The group on screen: its channels' listings for every day the guide keeps (Guide Days
     * Ahead), read in the background, so scrolling ahead in it never runs into the end of
     * what's loaded. Only the group's channels (at most [MAX_FULL_RANGE_CHANNELS], from the
     * top): all days for every channel of every playlist would be too much for smaller boxes.
     */
    fun ensureFullRange(channelKeys: List<String>) {
        if (!guideInDb || channelKeys.isEmpty()) return
        val todo = channelKeys.take(MAX_FULL_RANGE_CHANNELS).filter { it !in fullRangeChannels }
        if (todo.isEmpty()) return
        fullRangeJob?.cancel()
        fullRangeJob = scope.launch(Dispatchers.IO) {
            val settings = prefs.currentSettings()
            val now = System.currentTimeMillis()
            val from = now - HOUR
            val to = now + settings.epgFutureDays.coerceAtLeast(1) * 24 * HOUR
            // A batch at a time, so the first channels fill in quickly and a group change
            // stops the rest.
            for (batch in todo.chunked(60)) {
                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                val got = runCatching { guideDb.range(from, to, light = lightPrograms, channels = batch) }.getOrNull() ?: return@launch
                rangeMutex.withLock {
                    val merged = HashMap(_programs.value)
                    batch.forEach { ch ->
                        val list = got[ch].orEmpty()
                        val cur = merged[ch]
                        merged[ch] = when {
                            list.isEmpty() -> cur ?: return@forEach
                            cur.isNullOrEmpty() -> list
                            else -> {
                                val starts = cur.mapTo(HashSet()) { it.startMs }
                                val extra = list.filter { it.startMs !in starts }
                                if (extra.isEmpty()) cur else (cur + extra).sortedBy { it.startMs }
                            }
                        }
                    }
                    _programs.value = merged
                }
                fullRangeChannels += batch
            }
        }
    }

    // ---------------------------------------------------------------- Xtream catch-up archive

    /** Channels whose archive listings were already fetched this session. */
    private val archiveFetched = java.util.Collections.synchronizedSet(HashSet<String>())
    private val archivePermits = kotlinx.coroutines.sync.Semaphore(3)
    @Volatile private var archivePausedUntil = 0L

    /**
     * Past listings for Xtream catch-up channels, the way TiviMate gets them: many providers'
     * guide file only covers about a day back, while the Xtream API keeps the full catch-up
     * archive (up to 7 days or more) per channel. Fetched for the channels you're looking at,
     * once per session, and stored with the rest of the guide.
     */
    fun loadXtreamArchive(channels: List<LiveChannel>) {
        val wanted = channels.filter { it.catchup != null && it.key !in archiveFetched }
        if (wanted.isEmpty()) return
        wanted.forEach { archiveFetched += it.key }
        if (System.currentTimeMillis() < archivePausedUntil) {
            wanted.forEach { archiveFetched -= it.key }
            return
        }
        scope.launch {
            val playlists = prefs.currentPlaylists().associateBy { it.id }
            val settings = prefs.currentSettings()
            wanted.forEach { ch ->
                val pl = playlists[ch.sourceId]?.takeIf { it.isXtream } ?: return@forEach
                val streamId = Regex("""/(\d+)(?:\.[a-z0-9]+)?(?:\?.*)?$""", RegexOption.IGNORE_CASE)
                    .find(ch.url)?.groupValues?.get(1) ?: return@forEach
                archivePermits.withPermit {
                    // The provider said "too many requests": leave it alone for a few minutes, so
                    // these lookups never stand between you and playing something.
                    if (System.currentTimeMillis() < archivePausedUntil) { archiveFetched -= ch.key; return@withPermit }
                    runCatching {
                        val url = "${pl.xtreamBase()}/player_api.php?username=" +
                            java.net.URLEncoder.encode(pl.xtreamUsername.trim(), "UTF-8") +
                            "&password=" + java.net.URLEncoder.encode(pl.xtreamPassword.trim(), "UTF-8") +
                            "&action=get_simple_data_table&stream_id=$streamId"
                        val json = JSONObject(getText(url, pl.userAgent.ifBlank { DEFAULT_UA }))
                        val arr = json.optJSONArray("epg_listings") ?: return@runCatching
                        fun b64(v: String): String = runCatching {
                            String(android.util.Base64.decode(v, android.util.Base64.DEFAULT), Charsets.UTF_8)
                        }.getOrDefault(v)
                        val list = ArrayList<EpgProgram>()
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            val start = o.optString("start_timestamp").toLongOrNull()?.times(1000) ?: continue
                            val stop = o.optString("stop_timestamp").toLongOrNull()?.times(1000)
                                ?: o.optString("end_timestamp").toLongOrNull()?.times(1000) ?: continue
                            if (stop <= start) continue
                            val title = b64(o.optString("title")).trim()
                            if (title.isEmpty()) continue
                            list += EpgProgram(
                                startMs = start,
                                stopMs = stop,
                                title = title,
                                description = b64(o.optString("description")).trim().takeIf { it.isNotEmpty() }
                            )
                        }
                        if (list.isEmpty()) return@runCatching
                        list.sortBy { it.startMs }
                        val now = System.currentTimeMillis()
                        // Keep what the guide file already has from about now on; the archive
                        // fills in the past.
                        val pastEnd = minOf(now, list.last().stopMs)
                        val past = list.filter { it.startMs < pastEnd }
                        val existing = _programs.value[ch.key].orEmpty()
                        // Beyond the end of the guide file's listings, the archive's later
                        // shows are used too (some guide files only cover a day ahead).
                        val existingEnd = existing.maxOfOrNull { it.stopMs } ?: now
                        val later = list.filter { it.startMs >= maxOf(existingEnd, now) }
                        if (past.isEmpty() && later.isEmpty()) return@runCatching
                        val from = past.firstOrNull()?.startMs ?: pastEnd
                        val keep = existing.filter { it.startMs >= pastEnd || it.startMs < from }
                        val merged = (past + keep + later).sortedBy { it.startMs }
                            .fold(ArrayList<EpgProgram>()) { acc, p -> if (acc.isEmpty() || p.startMs >= acc.last().stopMs - 60_000) acc += p; acc }
                        if (guideInDb) runCatching {
                            if (past.isNotEmpty()) guideDb.putChannelRange(ch.key, from, pastEnd, past)
                            if (later.isNotEmpty()) guideDb.putChannelRange(ch.key, later.first().startMs, later.last().stopMs, later)
                        }
                        _programs.value = _programs.value + (ch.key to merged)
                        loadedFrom = minOf(loadedFrom, from)
                    }.onFailure {
                        Log.w(TAG, "Catch-up archive for ${ch.name} unavailable", it)
                        if (it.message?.contains("429") == true) {
                            archivePausedUntil = System.currentTimeMillis() + 5 * 60_000L
                            archiveFetched -= ch.key
                            LIVE_REPORT.add("Provider said too many requests (HTTP 429): catch-up lookups paused for 5 minutes")
                        }
                    }
                }
            }
        }
    }

    /** One channel's whole schedule (overlay mode's days, catch-up following into later shows). */
    /** A channel's listings from an hour ago to [days] ahead (series recordings look through these). */
    suspend fun upcomingListings(channelKey: String, days: Int): List<EpgProgram> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!guideInDb) return@withContext _programs.value[channelKey].orEmpty()
        runCatching { guideDb.channelRange(channelKey, now - HOUR, now + days * 24 * HOUR) }
            .getOrNull()?.takeIf { it.isNotEmpty() } ?: _programs.value[channelKey].orEmpty()
    }

    fun ensureChannelSchedule(channelKey: String) {
        if (!guideInDb) return
        scope.launch {
            val now = System.currentTimeMillis()
            val settings = prefs.currentSettings()
            val list = runCatching {
                guideDb.channelRange(channelKey, now - settings.epgPastHours.coerceAtLeast(1) * HOUR,
                    now + settings.epgFutureDays.coerceAtLeast(1) * 24 * HOUR)
            }.getOrNull() ?: return@launch
            val cur = _programs.value
            if ((cur[channelKey]?.size ?: 0) >= list.size) return@launch
            _programs.value = cur + (channelKey to list)
        }
    }

    /** Everything the matched guide depends on; a different value means the cache is stale. */
    private suspend fun guideFingerprint(settings: LiveTvSettings, targets: List<EpgTarget>): String {
        val overrides = prefs.userState.first().epgOverrides
        val sb = StringBuilder()
        sb.append(GUIDE_CACHE_VERSION).append('|')
        sb.append(settings.epgPastHours).append('|').append(settings.epgFutureDays).append('|')
        targets.forEach { t ->
            val f = epgFile(t.fileId)
            sb.append(t.fileId).append(':').append(f.length()).append(':').append(contentStamp(f)).append(',')
        }
        sb.append('|').append(overrides.hashCode())
        sb.append('|').append(_channels.value.size).append(':').append(_channels.value.sumOf { it.key.hashCode().toLong() })
        return sb.toString()
    }

    private suspend fun loadSavedGuide(settings: LiveTvSettings, targets: List<EpgTarget>): Boolean = withContext(Dispatchers.IO) {
        val file = savedGuideFile
        if (!file.exists() || _channels.value.isEmpty()) return@withContext false
        val expected = guideFingerprint(settings, targets)
        runCatching {
            java.io.DataInputStream(java.io.BufferedInputStream(java.util.zip.GZIPInputStream(file.inputStream()), 64 * 1024)).use { input ->
                if (input.readUTF() != expected) return@withContext false
                val programs = HashMap<String, List<EpgProgram>>()
                repeat(input.readInt()) {
                    val key = input.readUTF()
                    val list = ArrayList<EpgProgram>()
                    repeat(input.readInt()) {
                        val start = input.readLong()
                        val stop = input.readLong()
                        val title = input.readUTF()
                        val desc = readOpt(input)
                        val category = readOpt(input)
                        val episode = XmltvParser.cleanEpisode(readOpt(input))
                        val icon = readOpt(input)
                        val year = input.readInt().takeIf { it > 0 }
                        val people = List(input.readInt()) { input.readUTF() }
                        list += EpgProgram(start, stop, title, desc, category, episode, icon, year, people)
                    }
                    programs[key] = list
                }
                val auto = HashMap<String, EpgAssignment>()
                repeat(input.readInt()) {
                    auto[input.readUTF()] = EpgAssignment(input.readUTF(), input.readUTF())
                }
                // Drop shows that have ended since the cache was saved (outside the window).
                val windowStart = System.currentTimeMillis() - settings.epgPastHours.coerceAtLeast(1) * HOUR
                _programs.value = programs.mapValues { (_, l) -> l.filter { it.stopMs > windowStart } }
                _autoMatches.value = auto
                epgDetailsPending = true
                true
            }
        }.getOrElse {
            Log.w(TAG, "Saved guide unreadable", it)
            false
        }
    }

    private fun saveGuide(fingerprint: String, programs: Map<String, List<EpgProgram>>, auto: Map<String, EpgAssignment>) {
        // Huge guides (hundreds of thousands of listings) would make a very large file that's
        // slow to write and read; those are simply re-matched at start as before.
        if (programs.values.sumOf { it.size } > MAX_SAVED_LISTINGS) {
            savedGuideFile.delete()
            return
        }
        runCatching {
            val tmp = File(baseDir, "guide_cache.tmp")
            java.io.DataOutputStream(java.io.BufferedOutputStream(java.util.zip.GZIPOutputStream(tmp.outputStream()), 64 * 1024)).use { out ->
                out.writeUTF(fingerprint)
                out.writeInt(programs.size)
                programs.forEach { (key, list) ->
                    out.writeUTF(key)
                    out.writeInt(list.size)
                    list.forEach { p ->
                        out.writeLong(p.startMs)
                        out.writeLong(p.stopMs)
                        out.writeUTF(p.title.take(500))
                        writeOpt(out, p.description?.take(4000))
                        writeOpt(out, p.category?.take(200))
                        writeOpt(out, p.episode?.take(200))
                        writeOpt(out, p.icon?.take(1000))
                        out.writeInt(p.year ?: 0)
                        out.writeInt(p.people.size.coerceAtMost(20))
                        p.people.take(20).forEach { out.writeUTF(it.take(200)) }
                    }
                }
                out.writeInt(auto.size)
                auto.forEach { (key, a) -> out.writeUTF(key); out.writeUTF(a.sourceId); out.writeUTF(a.xmltvId) }
            }
            if (!tmp.renameTo(savedGuideFile)) { tmp.copyTo(savedGuideFile, overwrite = true); tmp.delete() }
        }.onFailure { Log.w(TAG, "Couldn't save the guide", it) }
    }

    private fun readOpt(input: java.io.DataInputStream): String? = if (input.readBoolean()) input.readUTF() else null

    private fun writeOpt(out: java.io.DataOutputStream, value: String?) {
        out.writeBoolean(value != null)
        if (value != null) out.writeUTF(value)
    }

    private fun setStatus(loading: Boolean, message: String?, quiet: Boolean = false) {
        _status.value = _status.value.copy(loading = loading, message = message, quiet = quiet)
    }

    private data class EpgTarget(
        val fileId: String,
        val sourceId: String?,
        val name: String,
        val url: String,
        val userAgent: String
    )

    /** Named EPG sources first (they win on conflicts), then EPG URLs embedded in playlists. */
    private suspend fun collectEpgTargets(): List<EpgTarget> {
        val targets = mutableListOf<EpgTarget>()
        prefs.currentEpgSources().filter { it.enabled && it.url.isNotBlank() }.forEach {
            targets += EpgTarget(it.id, it.id, it.name, it.url, "")
        }
        val playlists = prefs.currentPlaylists().filter { it.liveEnabled && it.useEmbeddedEpg }
        for (pl in playlists) {
            val urls = mutableListOf<String>()
            pl.xtreamEpgUrl()?.let { urls += it }
            urls += embeddedEpgUrls[pl.id].orEmpty()
            urls.distinct().forEach { url ->
                if (targets.none { it.url == url }) {
                    targets += EpgTarget("auto_" + sha1(url), null, "${pl.name} (built-in)", url, pl.userAgent)
                }
            }
        }
        return targets
    }

    private val embeddedEpgUrls = HashMap<String, List<String>>()

    private suspend fun buildChannels() = withContext(Dispatchers.IO) {
        val playlists = prefs.currentPlaylists().filter { it.liveEnabled }
        val multi = playlists.size > 1
        val out = ArrayList<LiveChannel>()
        val usedKeys = HashSet<String>()
        var counter = 1
        for ((plIndex, pl) in playlists.withIndex()) {
            val file = playlistFile(pl.id)
            if (!file.exists()) continue
            setStatus(loading = true, message = "Reading channels from \"${pl.name}\"" + (if (playlists.size > 1) " (${plIndex + 1} of ${playlists.size})" else "") + "…")
            val parsed = runCatching { openMaybeGzip(file).bufferedReader().use { M3uParser.parse(it) } }
                .onFailure { Log.w(TAG, "Parse ${pl.name} failed", it) }
                .getOrNull() ?: continue
            embeddedEpgUrls[pl.id] = parsed.epgUrls
            for (e in parsed.entries) {
                // Many providers' M3U links ("m3u_plus") also list every movie and episode,
                // often 100,000+ entries. Those aren't TV channels, and loading them all into the
                // guide used enough memory to crash Live TV on some devices.
                if (isVodEntry(e.url)) continue
                val groupTitle = e.group?.ifBlank { null } ?: "Uncategorized"
                val baseKey = "${pl.id}|${e.tvgId ?: ""}|${e.name}"
                var key = baseKey
                var n = 2
                while (!usedKeys.add(key)) { key = "$baseKey#${n++}" }
                val number = e.chno ?: counter
                counter = maxOf(counter, number) + 1
                val headers = if (pl.userAgent.isNotBlank() && "User-Agent" !in e.headers) {
                    e.headers + ("User-Agent" to pl.userAgent)
                } else e.headers
                out += LiveChannel(
                    key = key,
                    sourceId = pl.id,
                    sourceName = pl.name,
                    name = e.name,
                    tvgId = e.tvgId,
                    tvgName = e.tvgName,
                    logo = e.logo,
                    groupId = if (multi) "${pl.id}::$groupTitle" else groupTitle,
                    // Names stay exactly as the playlist has them (the playlist is shown, if you want
                    // it, with "Group by playlist").
                    group = groupTitle,
                    number = number,
                    url = e.url,
                    headers = headers,
                    catchup = e.catchup,
                    drm = e.drm
                )
            }
            prefs.updatePlaylists { list -> list.map { if (it.id == pl.id) it.copy(channelCount = parsed.entries.size) else it } }
        }
        _channels.value = out
    }

    private suspend fun buildPrograms(settings: LiveTvSettings, targets: List<EpgTarget>) {
        val t0 = System.currentTimeMillis()
        buildProgramsInner(settings, targets)
        LIVE_REPORT.add("Guide matched and stored: ${_programs.value.size} channels in ${System.currentTimeMillis() - t0} ms")
    }

    private suspend fun buildProgramsInner(settings: LiveTvSettings, targets: List<EpgTarget>) = withContext(Dispatchers.IO) {
        val all = _channels.value
        if (all.isEmpty()) {
            _programs.value = emptyMap()
            return@withContext
        }
        // Channels no profile shows (hidden, or in a hidden group, in every profile) get no
        // listings: nobody sees them, and big providers' hidden groups made the guide database
        // many times bigger than what's watched. Showing them again reads their listings back.
        val hidden = prefs.currentHiddenEverywhere()
        val skipped = HashSet<String>()
        val channels = all.filter { c -> (!hidden.hides(c.key, c.groupId)).also { shown -> if (!shown) skipped += c.key } }
        val now = System.currentTimeMillis()
        val windowStart = now - settings.epgPastHours.coerceAtLeast(1) * HOUR
        val windowEnd = now + settings.epgFutureDays.coerceAtLeast(1) * 24 * HOUR

        // Hand-picked guides (long-press > Change EPG) win over automatic matching.
        val overrides = prefs.userState.first().epgOverrides
            .filterKeys { key -> channels.any { it.key == key } }

        val byTvgId = HashMap<String, MutableList<LiveChannel>>()
        val byName = HashMap<String, MutableList<LiveChannel>>()
        channels.forEach { c ->
            if (c.key in overrides) return@forEach
            c.tvgId?.lowercase()?.let { byTvgId.getOrPut(it) { ArrayList() }.add(c) }
            normalize(c.tvgName ?: "").takeIf { it.isNotEmpty() }?.let { byName.getOrPut(it) { ArrayList() }.add(c) }
            normalize(c.name).takeIf { it.isNotEmpty() }?.let { byName.getOrPut(it) { ArrayList() }.add(c) }
        }

        // Every guide is read; each channel keeps its best candidate:
        //   1. real listings beat placeholder listings ("Programming", "No information", …)
        //   2. a tvg-id match beats a name match
        //   3. then the earlier guide in the list
        // so a guide full of placeholders can't hide real listings from another guide.
        data class Candidate(val score: Int, val sourceId: String, val xmltvId: String, val programs: List<EpgProgram>)
        val best = HashMap<String, Candidate>()
        val pinned = HashMap<String, List<EpgProgram>>()
        val sourceLists = ArrayList<EpgSourceChannels>()
        val sourceMeta = ArrayList<Triple<EpgTarget, String, List<EpgChannelEntry>>>()

        for ((order, target) in targets.withIndex()) {
            val file = epgFile(target.fileId)
            if (!file.exists()) continue
            // How far through each guide file it is, so a big guide doesn't look frozen.
            val fileSize = file.length().coerceAtLeast(1L)
            val step = if (targets.size > 1) " (${order + 1} of ${targets.size})" else ""
            var shownAt = 0L
            val showProgress: (Long) -> Unit = { done ->
                val now = System.currentTimeMillis()
                if (now - shownAt > 750) {
                    shownAt = now
                    setStatus(loading = true, message = "Reading guide \"${target.name}\"$step… ${(done * 100 / fileSize).coerceIn(0, 99)}%")
                }
            }
            val pinnedHere = overrides.filterValues { it.sourceId == target.fileId }
            val idHits = HashMap<String, MutableSet<LiveChannel>>()
            val nameHits = HashMap<String, MutableSet<LiveChannel>>()
            val parsed = runCatching {
                openMaybeGzip(file, showProgress).use { input ->
                    XmltvParser.parse(input, windowStart, windowEnd) { xmlChannels ->
                        xmlChannels.values.forEach { xc ->
                            byTvgId[xc.id.lowercase()]?.let { idHits.getOrPut(xc.id) { LinkedHashSet() }.addAll(it) }
                            (xc.displayNames + xc.id).forEach { dn ->
                                byName[normalize(dn)]?.let { nameHits.getOrPut(xc.id) { LinkedHashSet() }.addAll(it) }
                            }
                        }
                        if (xmlChannels.isEmpty()) null
                        else idHits.keys + nameHits.keys + pinnedHere.values.map { it.xmltvId }
                    }
                }
            }.onFailure { Log.w(TAG, "EPG parse ${target.name} failed", it) }.getOrNull() ?: continue

            val entries = if (parsed.channels.isNotEmpty()) {
                parsed.channels.values.map { EpgChannelEntry(it.id, it.displayNames, it.icon) }
            } else {
                parsed.programs.keys.map { EpgChannelEntry(it, emptyList(), null) }
            }
            val label = runCatching { java.net.URI(target.url).host?.removePrefix("www.") }.getOrNull()
                ?.takeIf { it.isNotBlank() } ?: target.name
            sourceMeta += Triple(target, label, entries.sortedBy { it.displayName.lowercase() })
            // How far ahead this guide's listings actually go (the file's own last show), so a
            // guide that stops early can be told apart from the app cutting it short.
            run {
                val lastStop = parsed.programs.values.maxOfOrNull { l -> l.maxOfOrNull { it.stopMs } ?: 0L } ?: 0L
                if (lastStop > 0) {
                    val fmt = java.text.SimpleDateFormat("EEE d MMM, h:mm a", java.util.Locale.getDefault())
                    val hours = ((lastStop - System.currentTimeMillis()) / HOUR).coerceAtLeast(0)
                    LIVE_REPORT.add(
                        "Guide \"${target.name}\": listings until ${fmt.format(java.util.Date(lastStop))} " +
                            "(about $hours hours ahead; set to ${settings.epgFutureDays} days)"
                    )
                }
            }

            pinnedHere.forEach { (key, a) -> pinned[key] = cleanListings(parsed.programs[a.xmltvId].orEmpty()) }

            if (idHits.isEmpty() && nameHits.isEmpty()) {
                // Guide had no <channel> list before programs: match program channel ids directly.
                parsed.programs.keys.forEach { id ->
                    byTvgId[id.lowercase()]?.let { idHits.getOrPut(id) { LinkedHashSet() }.addAll(it) }
                    byName[normalize(id)]?.let { nameHits.getOrPut(id) { LinkedHashSet() }.addAll(it) }
                }
            }
            var count = 0
            fun offer(xmlId: String, chans: Set<LiveChannel>, idMatch: Boolean) {
                val raw = parsed.programs[xmlId] ?: return
                val list = cleanListings(raw)
                if (list.isEmpty()) return
                count += list.size
                val real = !isPlaceholderListing(list)
                // Higher is better; the guide's position only breaks ties.
                val score = (if (real) 4_000 else 0) + (if (idMatch) 2_000 else 0) - order
                chans.forEach { c ->
                    val cur = best[c.key]
                    if (cur == null || score > cur.score) best[c.key] = Candidate(score, target.fileId, xmlId, list)
                }
            }
            idHits.forEach { (xmlId, chans) -> offer(xmlId, chans, idMatch = true) }
            nameHits.forEach { (xmlId, chans) -> offer(xmlId, chans, idMatch = false) }
            if (target.sourceId != null) {
                prefs.updateEpgSources { l -> l.map { if (it.id == target.sourceId) it.copy(programCount = count) else it } }
            }
        }

        val result = HashMap<String, List<EpgProgram>>()
        val auto = HashMap<String, EpgAssignment>()
        best.forEach { (key, c) ->
            result[key] = c.programs
            auto[key] = EpgAssignment(c.sourceId, c.xmltvId)
        }
        result.putAll(pinned)
        // Unassigned in Assign EPG: no guide for these channels, automatic match included.
        overrides.filterValues { it.isNone }.keys.forEach { key -> result.remove(key); auto.remove(key) }
        // Which guide channels ended up feeding a playlist channel (for "Unassigned" in Assign EPG).
        val usedBySource = HashMap<String, MutableSet<String>>()
        auto.values.forEach { usedBySource.getOrPut(it.sourceId) { HashSet() } += it.xmltvId }
        overrides.values.forEach { usedBySource.getOrPut(it.sourceId) { HashSet() } += it.xmltvId }
        sourceMeta.forEach { (target, label, entries) ->
            sourceLists += EpgSourceChannels(target.fileId, target.name, label, entries, usedBySource[target.fileId].orEmpty())
        }
        _autoMatches.value = auto
        _epgSources.value = sourceLists
        saveSourceLists(targets, sourceLists)
        // Each channel's logo in the guide it's matched to (or assigned), for playlists that
        // prefer the guide's logos, and for channels whose playlist has none.
        val iconsBySource = sourceMeta.associate { (target, _, entries) ->
            target.fileId to entries.mapNotNull { e -> e.icon?.takeIf { it.isNotBlank() }?.let { e.id to it } }.toMap()
        }
        val logos = HashMap<String, String>()
        (auto + overrides).forEach { (key, a) -> iconsBySource[a.sourceId]?.get(a.xmltvId)?.let { logos[key] = it } }
        _epgLogos.value = logos
        saveEpgLogos(logos)
        _programs.value = result
        epgDetailsPending = false
        // Store the whole guide in the database and keep only the hours around now in memory.
        val stored = runCatching { guideDb.replaceAll(guideFingerprint(settings, targets), result, auto) }
            .onFailure { Log.w(TAG, "Couldn't store the guide", it) }.isSuccess
        if (stored) {
            lightPrograms = false
            val (from, to) = defaultWindow()
            _programs.value = result.mapValues { (_, l) -> l.filter { it.stopMs > from && it.startMs < to } }.filterValues { it.isNotEmpty() }
            fullRangeChannels.clear()
            loadedFrom = from
            loadedTo = to
            guideInDb = true
            saveSkipped(skipped)
            if (skipped.isNotEmpty()) LIVE_REPORT.add("Guide: ${skipped.size} hidden channels left out")
            scheduleCompact()
        } else {
            guideInDb = false
            loadedFrom = Long.MIN_VALUE
            loadedTo = Long.MAX_VALUE
        }
    }

    /**
     * Some guides add a long placeholder ("Programming", "No information") that overlaps the real
     * listings for the same time. Keep the real ones wherever they overlap.
     */
    private fun cleanListings(list: List<EpgProgram>): List<EpgProgram> {
        if (list.size < 2) return list
        val real = list.filter { !isPlaceholder(it.title) }
        val kept = if (real.isEmpty() || real.size == list.size) list else list.filter { p ->
            !isPlaceholder(p.title) || real.none { r -> r.startMs < p.stopMs && r.stopMs > p.startMs }
        }
        return resolveOverlaps(kept)
    }

    /**
     * Makes sure only one program covers any moment. When a long entry (often a "Programming"
     * filler) runs across later shows, it's cut off where the next show starts. Otherwise the
     * filler, having started earlier, is what counts as "on now" even while a real show is airing.
     */
    private fun resolveOverlaps(list: List<EpgProgram>): List<EpgProgram> {
        val sorted = list.sortedWith(compareBy<EpgProgram>({ it.startMs }, { isPlaceholder(it.title) }, { it.stopMs - it.startMs }))
        val out = ArrayList<EpgProgram>(sorted.size)
        for (p in sorted) {
            val last = out.lastOrNull()
            if (last != null && last.stopMs > p.startMs) {
                if (last.startMs == p.startMs) continue // same start: keep the one sorted first
                out[out.lastIndex] = last.copy(stopMs = p.startMs)
            }
            if (p.stopMs > p.startMs) out += p
        }
        return out
    }

    /** True when (almost) everything in a channel's listings is a placeholder. */
    private fun isPlaceholderListing(list: List<EpgProgram>): Boolean {
        val placeholders = list.count { isPlaceholder(it.title) }
        return placeholders * 10 >= list.size * 8
    }

    private fun isPlaceholder(title: String): Boolean =
        PLACEHOLDER_TITLES.matches(title.trim().lowercase())

    /**
     * Assign EPG changes applied straight to the stored guide instead of reading every guide
     * file again (which took as long as a full guide update, just to change one channel):
     *  - Unassign: the channel's listings are simply dropped. Nothing is read.
     *  - A guide channel picked by hand: only that one guide file is read, for just that channel.
     *  - Back to automatic: the guides' channel lists (already in memory, the ones Assign EPG
     *    shows) say which guide channels could match; only the guides that have one are read,
     *    for just those channels, and the best is picked the same way a full update picks.
     * Only if those lists aren't loaded yet does it fall back to reading every guide.
     * [changes]: channel key -> its new assignment (null = back to automatic).
     */
    fun applyEpgChanges(changes: Map<String, EpgAssignment?>) {
        if (changes.isEmpty()) return
        scope.launch {
            mutex.withLock {
                val quick = runCatching { applyEpgChangesQuick(changes) }
                    .onFailure { Log.w(TAG, "Quick EPG change failed; full re-match", it) }
                    .getOrDefault(false)
                if (!quick) {
                    LIVE_REPORT.add("Assign EPG: guide channel lists not ready, so every guide was read")
                    setStatus(loading = true, message = "Updating guide…")
                    buildPrograms(prefs.currentSettings(), collectEpgTargets())
                }
                _status.value = LiveTvStatus(loading = false, loadedOnce = true)
            }
        }
    }

    private suspend fun applyEpgChangesQuick(changes: Map<String, EpgAssignment?>): Boolean = withContext(Dispatchers.IO) {
        val settings = prefs.currentSettings()
        val targets = collectEpgTargets()
        val now = System.currentTimeMillis()
        val windowStart = now - settings.epgPastHours.coerceAtLeast(1) * HOUR
        val windowEnd = now + settings.epgFutureDays.coerceAtLeast(1) * 24 * HOUR
        val assigned = changes.filterValues { it != null && !it.isNone }.mapValues { it.value!! }

        // Back to automatic: possible matches, from the guides' channel lists.
        data class Cand(val order: Int, val sourceId: String, val xmltvId: String, val idMatch: Boolean)
        val autoBack = changes.filterValues { it == null }.keys
        val cands = HashMap<String, MutableList<Cand>>()
        if (autoBack.isNotEmpty()) {
            val lists = _epgSources.value
            if (lists.isEmpty()) return@withContext false
            val chans = _channels.value.filter { it.key in autoBack }
            targets.forEachIndexed { order, t ->
                val list = lists.firstOrNull { it.sourceId == t.fileId } ?: return@forEachIndexed
                chans.forEach { c ->
                    val tvg = c.tvgId?.lowercase()?.takeIf { it.isNotBlank() }
                    val names = listOfNotNull(c.tvgName, c.name).map { normalize(it) }.filter { it.isNotEmpty() }.toSet()
                    list.channels.forEach { e ->
                        val idMatch = tvg != null && e.id.lowercase() == tvg
                        val nameMatch = !idMatch && names.isNotEmpty() && (e.names + e.id).any { normalize(it) in names }
                        if (idMatch || nameMatch) cands.getOrPut(c.key) { ArrayList() } += Cand(order, t.fileId, e.id, idMatch)
                    }
                }
            }
        }

        // Each guide file read once, for just the channels needed from it.
        val wantedBySource = HashMap<String, MutableSet<String>>()
        assigned.values.forEach { wantedBySource.getOrPut(it.sourceId) { HashSet() } += it.xmltvId }
        cands.values.flatten().forEach { wantedBySource.getOrPut(it.sourceId) { HashSet() } += it.xmltvId }
        val programsBySource = HashMap<String, Map<String, List<EpgProgram>>>()
        val iconsBySource = HashMap<String, Map<String, String>>()
        for ((sourceId, wanted) in wantedBySource) {
            val target = targets.firstOrNull { it.fileId == sourceId } ?: continue
            val file = epgFile(target.fileId)
            if (!file.exists()) continue
            setStatus(loading = true, message = "Reading guide \"${target.name}\"…")
            val parsed = openMaybeGzip(file).use { input ->
                XmltvParser.parse(input, windowStart, windowEnd) { wanted }
            }
            programsBySource[sourceId] = parsed.programs
            iconsBySource[sourceId] = parsed.channels.mapNotNull { (id, ch) -> ch.icon?.takeIf { it.isNotBlank() }?.let { id to it } }.toMap()
        }

        val newPrograms = HashMap<String, List<EpgProgram>>()
        val newIcons = HashMap<String, String>()
        assigned.forEach { (key, a) ->
            newPrograms[key] = cleanListings(programsBySource[a.sourceId]?.get(a.xmltvId).orEmpty())
            iconsBySource[a.sourceId]?.get(a.xmltvId)?.let { newIcons[key] = it }
        }
        // Automatic: the same choice a full update makes (real listings first, then a tvg-id
        // match over a name match, then the guide higher in the list).
        val newAuto = HashMap<String, EpgAssignment>()
        cands.forEach { (key, list) ->
            var bestScore = Int.MIN_VALUE
            var best: Pair<Cand, List<EpgProgram>>? = null
            list.forEach { c ->
                val listings = cleanListings(programsBySource[c.sourceId]?.get(c.xmltvId).orEmpty())
                if (listings.isEmpty()) return@forEach
                val score = (if (!isPlaceholderListing(listings)) 4_000 else 0) + (if (c.idMatch) 2_000 else 0) - c.order
                if (score > bestScore) { bestScore = score; best = c to listings }
            }
            best?.let { (c, listings) ->
                newPrograms[key] = listings
                newAuto[key] = EpgAssignment(c.sourceId, c.xmltvId)
                iconsBySource[c.sourceId]?.get(c.xmltvId)?.let { newIcons[key] = it }
            }
        }

        val changed = changes.keys
        // Stored guide first (when the guide is kept in the database), then what's on screen.
        if (guideInDb) guideDb.replaceChannels(guideFingerprint(settings, targets), changed, newPrograms, newAuto)
        _programs.value = HashMap(_programs.value).apply {
            changed.forEach { remove(it) }
            newPrograms.forEach { (k, l) ->
                val shown = if (guideInDb) l.filter { it.stopMs > loadedFrom && it.startMs < loadedTo } else l
                if (shown.isNotEmpty()) put(k, shown)
            }
        }
        _autoMatches.value = (_autoMatches.value - changed) + newAuto
        fullRangeChannels.removeAll(changed)
        val logos = HashMap(_epgLogos.value).apply { changed.forEach { remove(it) }; putAll(newIcons) }
        _epgLogos.value = logos
        saveEpgLogos(logos)
        // Keep the "already used" marks in Assign EPG up to date.
        val used = (assigned.values + newAuto.values).groupBy({ it.sourceId }, { it.xmltvId })
        if (used.isNotEmpty()) {
            _epgSources.value = _epgSources.value.map { s ->
                used[s.sourceId]?.let { ids -> s.copy(usedIds = s.usedIds + ids) } ?: s
            }
        }
        LIVE_REPORT.add(
            "Assign EPG: ${changed.size} channel(s) updated, " +
                (if (programsBySource.isEmpty()) "no guide read" else "read ${programsBySource.size} of ${targets.size} guide(s)")
        )
        true
    }

    fun rematchEpg() {
        scope.launch {
            mutex.withLock {
                setStatus(loading = true, message = "Updating guide…")
                buildPrograms(prefs.currentSettings(), collectEpgTargets())
                _status.value = LiveTvStatus(loading = false, loadedOnce = true)
            }
        }
    }

    // ---------------------------------------------------------------- IO helpers

    private fun playlistFile(id: String) = File(playlistDir, "$id.m3u")
    private fun epgFile(id: String) = File(epgDir, "$id.xml")

    /**
     * Downloads [url] to [target]. Returns false when nothing changed: the server said "not
     * modified" (we send the ETag / Last-Modified from last time), or the new file is identical.
     * Unchanged files skip the re-reading and re-matching that follows a download.
     */
    private suspend fun download(url: String, target: File, userAgent: String, progressLabel: String? = null): Boolean = withContext(Dispatchers.IO) {
        require(url.isNotBlank()) { "No URL set" }
        target.parentFile?.mkdirs()
        val meta = File(target.parentFile, target.name + ".meta")
        val (etag, lastModified) = if (target.exists() && meta.exists()) {
            meta.readLines().let { it.getOrNull(0).orEmpty() to it.getOrNull(1).orEmpty() }
        } else "" to ""
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent.ifBlank { DEFAULT_UA })
            .apply {
                if (etag.isNotBlank()) header("If-None-Match", etag)
                if (lastModified.isNotBlank()) header("If-Modified-Since", lastModified)
            }
            .build()
        http.newCall(request).execute().use { response ->
            if (response.code == 304 && target.exists()) {
                target.setLastModified(System.currentTimeMillis()) // checked again after the usual interval
                return@withContext false
            }
            if (!response.isSuccessful) error(httpError(response.code))
            val body = response.body ?: error("Empty response")
            val tmp = File(target.parentFile, target.name + ".tmp")
            // With a label: how much has come in so far, so a big download doesn't look frozen.
            val total = body.contentLength().takeIf { it > 0 }
            body.byteStream().use { raw ->
                // Saved zipped: guide files (XMLTV) and big playlists shrink to about a tenth,
                // and plain guides of several hundred MB made the app take up close to 1 GB.
                // Ones that already arrive zipped (.xml.gz) are kept as they are.
                val input = BufferedInputStream(raw, 64 * 1024)
                input.mark(2)
                val alreadyZipped = input.read() == 0x1f && input.read() == 0x8b
                input.reset()
                val fileOut = tmp.outputStream()
                (if (alreadyZipped) fileOut else fastGzip(fileOut)).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read = 0L
                    var shownAt = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        read += n
                        if (progressLabel != null) {
                            val now = System.currentTimeMillis()
                            if (now - shownAt > 750) {
                                shownAt = now
                                setStatus(loading = true, message = "$progressLabel… " + sizeLabel(read) + (total?.let { " of " + sizeLabel(it) } ?: ""))
                            }
                        }
                    }
                }
            }
            if (tmp.length() == 0L) {
                tmp.delete()
                error("Empty response")
            }
            runCatching {
                meta.writeText(response.header("ETag").orEmpty() + "\n" + response.header("Last-Modified").orEmpty())
            }
            val same = target.exists() && target.length() == tmp.length() && sameContent(target, tmp)
            if (same) {
                tmp.delete()
                target.setLastModified(System.currentTimeMillis())
                return@withContext false
            }
            if (!tmp.renameTo(target)) {
                tmp.copyTo(target, overwrite = true)
                tmp.delete()
            }
            markChanged(target)
            true
        }
    }

    /**
     * When a downloaded file last really changed. The saved channel list and guide are checked
     * against this, not the file's date: the date is also bumped every time an update finds
     * nothing new, which used to make every restart re-read all playlists and guides.
     */
    private fun stampFile(f: File) = File(f.parentFile, f.name + ".stamp")

    private fun contentStamp(f: File): String =
        runCatching { stampFile(f).readText().trim() }.getOrNull()?.takeIf { it.isNotEmpty() }
            ?: "${f.length()}"

    private fun markChanged(f: File) {
        runCatching { stampFile(f).writeText(System.currentTimeMillis().toString()) }
    }

    private fun sameContent(a: File, b: File): Boolean = runCatching {
        fun digest(f: File): ByteArray {
            val md = java.security.MessageDigest.getInstance("MD5")
            f.inputStream().use { input ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            return md.digest()
        }
        digest(a).contentEquals(digest(b))
    }.getOrDefault(false)

    // ---------------------------------------------------------------- Xtream Codes API

    /**
     * Loads an Xtream login through the Xtream API (player_api.php), the way TiviMate does:
     * account check, categories, then live streams, written out as an M3U file so the rest of
     * Live TV treats it like any playlist. Much lighter for the provider than the one-shot
     * get.php playlist, which many panels time out on (HTTP 502) or switch off. Falls back to
     * get.php if the API isn't available.
     */
    private suspend fun downloadXtream(pl: PlaylistSource, target: File) = withContext(Dispatchers.IO) {
        require(pl.xtreamBase().isNotBlank()) { "No server set" }
        require(pl.xtreamUsername.isNotBlank() && pl.xtreamPassword.isNotBlank()) { "Username and password are required" }
        val api = pl.xtreamApiUrl()
        val apiResult = runCatching {
            // 1. Account
            val info = JSONObject(getText(api, pl.userAgent))
            // Which stream formats this account may use (some panels turn off .ts and only
            // allow .m3u8; asking for .ts then fails on every channel with "bad http status").
            allowedFormats = info.optJSONObject("user_info")?.optJSONArray("allowed_output_formats")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it).lowercase() }.toSet()
            } ?: emptySet()
            // Catch-up links are in the server's local time. When the server's time zone differs
            // from the TV's (say the server runs on UTC and the TV is in London in summer),
            // every replay started an hour off. Remember the server's zone for catch-up.
            info.optJSONObject("server_info")?.optString("timezone")?.takeIf { it.isNotBlank() }?.let { tz ->
                if (tz != pl.serverTimezone) {
                    prefs.updatePlaylists { list -> list.map { if (it.id == pl.id) it.copy(serverTimezone = tz) else it } }
                }
            }
            info.optJSONObject("user_info")?.let { ui ->
                accountOf(ui)?.let { saveAccount(pl, it) }
                if (ui.optString("auth") == "0") throw XtreamLoginError("Login failed: check the username and password")
                val status = ui.optString("status")
                if (status.isNotBlank() && !status.equals("Active", ignoreCase = true)) {
                    throw XtreamLoginError("Account $status")
                }
                ui.optString("exp_date").toLongOrNull()?.let { exp ->
                    if (exp > 0 && exp * 1000 < System.currentTimeMillis()) {
                        val date = java.text.DateFormat.getDateInstance().format(java.util.Date(exp * 1000))
                        throw XtreamLoginError("Account expired on $date")
                    }
                }
            } ?: if (info.has("user_info")) Unit else error("Not an Xtream API response")

            // 2. Categories
            val categories = HashMap<String, String>()
            runCatching {
                val arr = org.json.JSONArray(getText("$api&action=get_live_categories", pl.userAgent))
                for (i in 0 until arr.length()) {
                    val c = arr.optJSONObject(i) ?: continue
                    categories[c.optString("category_id")] = c.optString("category_name")
                }
            }

            // 3. Live streams, streamed straight into an M3U file
            writeXtreamPlaylist(pl, "$api&action=get_live_streams", categories, target)
        }
        val error = apiResult.exceptionOrNull() ?: return@withContext
        if (error is XtreamLoginError) throw error
        Log.w(TAG, "Xtream API failed for ${pl.name}, trying get.php: ${error.message}")
        // Fallback: the classic one-shot playlist. If that fails too, report the API error.
        runCatching { download(pl.resolvedUrl(), target, pl.userAgent) }
            .onFailure { throw IllegalStateException(error.message ?: it.message) }
    }

    private class XtreamLoginError(message: String) : Exception(message)

    /** Stream formats the provider allows for the account being loaded (from user_info). */
    @Volatile private var allowedFormats: Set<String> = emptySet()

    private fun xtreamExtension(pl: PlaylistSource): String = when (pl.streamFormat) {
        "ts" -> "ts"
        "m3u8" -> "m3u8"
        // Auto: .ts unless the provider only allows HLS.
        else -> if (allowedFormats.isNotEmpty() && "ts" !in allowedFormats && "m3u8" in allowedFormats) "m3u8" else "ts"
    }

    private fun writeXtreamPlaylist(pl: PlaylistSource, url: String, categories: Map<String, String>, target: File) {
        val ext = xtreamExtension(pl)
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".tmp")
        val base = pl.xtreamBase()
        val user = java.net.URLEncoder.encode(pl.xtreamUsername.trim(), "UTF-8")
        val pass = java.net.URLEncoder.encode(pl.xtreamPassword.trim(), "UTF-8")
        var count = 0
        val request = Request.Builder().url(url).header("User-Agent", pl.userAgent.ifBlank { DEFAULT_UA }).build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error(httpError(response.code))
            val body = response.body ?: error("Empty response")
            tmp.bufferedWriter().use { out ->
                out.write("#EXTM3U\n")
                android.util.JsonReader(body.charStream()).use { reader ->
                    reader.beginArray()
                    while (reader.hasNext()) {
                        val f = HashMap<String, String>()
                        reader.beginObject()
                        while (reader.hasNext()) {
                            val name = reader.nextName()
                            when (reader.peek()) {
                                android.util.JsonToken.STRING -> f[name] = reader.nextString()
                                android.util.JsonToken.NUMBER -> f[name] = reader.nextString()
                                android.util.JsonToken.BOOLEAN -> f[name] = reader.nextBoolean().toString()
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()
                        val streamId = f["stream_id"]
                        if (streamId.isNullOrBlank()) continue
                        val title = (f["name"] ?: "Channel $streamId").replace("\n", " ").trim()
                        val attrs = buildString {
                            fun attr(k: String, v: String?) {
                                if (!v.isNullOrBlank()) append(" $k=\"${v.replace("\"", "'")}\"")
                            }
                            attr("tvg-id", f["epg_channel_id"])
                            attr("tvg-name", title)
                            attr("tvg-logo", f["stream_icon"])
                            attr("group-title", categories[f["category_id"]] ?: "Uncategorized")
                            attr("tvg-chno", f["num"])
                            if (f["tv_archive"] == "1") {
                                attr("catchup", "xc")
                                attr("catchup-days", f["tv_archive_duration"]?.takeIf { it != "0" } ?: "1")
                            }
                        }
                        out.write("#EXTINF:-1$attrs,$title\n")
                        out.write("$base/live/$user/$pass/$streamId.$ext\n")
                        count++
                        if (count % 500 == 0) setStatus(loading = true, message = "Loading channels from ${pl.name}… ${"%,d".format(count)}")
                    }
                    reader.endArray()
                }
            }
        }
        if (count == 0) {
            tmp.delete()
            error("The provider returned no live channels")
        }
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
    }

    /** Playlists whose server time zone was already looked up this session. */
    private val zoneTried = java.util.Collections.synchronizedSet(HashSet<String>())

    /**
     * M3U playlists from Xtream servers: the server's time zone, learned from the server the
     * channel links point to (its player_api.php, with the username and password in the link),
     * once. Catch-up links are in server time; without it, replays could start hours off or be
     * refused. Xtream logins already learn it when they load.
     */
    suspend fun learnServerZone(channel: LiveChannel): String? = withContext(Dispatchers.IO) {
        val pl = prefs.currentPlaylists().firstOrNull { it.id == channel.sourceId } ?: return@withContext null
        pl.serverTimezone.takeIf { it.isNotBlank() }?.let { return@withContext it }
        if (!zoneTried.add(pl.id)) return@withContext null
        val m = Regex("""^(https?://[^/]+)/(?:live/)?([^/]+)/([^/]+)/(\d+)(\.[a-z0-9]+)?(\?.*)?$""", RegexOption.IGNORE_CASE)
            .find(channel.url) ?: return@withContext null
        val (host, user, pass) = m.destructured
        val tz = runCatching {
            val url = "$host/player_api.php?username=" + java.net.URLEncoder.encode(user, "UTF-8") +
                "&password=" + java.net.URLEncoder.encode(pass, "UTF-8")
            JSONObject(getText(url, pl.userAgent.ifBlank { DEFAULT_UA }))
                .optJSONObject("server_info")?.optString("timezone")?.takeIf { it.isNotBlank() }
        }.getOrNull()
        LIVE_REPORT.add(if (tz != null) "Server time zone for \"${pl.name}\": $tz" else "Server time zone for \"${pl.name}\": unknown")
        if (tz != null) prefs.updatePlaylists { list -> list.map { if (it.id == pl.id) it.copy(serverTimezone = tz) else it } }
        tz
    }

    /** Xtream user_info → the account details worth showing. */
    private fun accountOf(ui: JSONObject): PlaylistAccount? {
        if (ui.optString("auth") == "0") return null
        val exp = ui.optString("exp_date").toLongOrNull()?.takeIf { it > 0 }?.times(1000) ?: 0L
        return PlaylistAccount(
            expiresAtMs = exp,
            status = ui.optString("status"),
            maxConnections = ui.optString("max_connections").toIntOrNull() ?: 0,
            activeConnections = ui.optString("active_cons").toIntOrNull() ?: 0,
            checkedAtMs = System.currentTimeMillis()
        )
    }

    private suspend fun saveAccount(pl: PlaylistSource, a: PlaylistAccount) {
        prefs.setPlaylistAccount(pl.id, a)
        a.expiryLabel()?.let { LIVE_REPORT.add("Account for \"${pl.name}\": expires $it") }
        warnIfExpiring(pl.id, pl.name, a)
    }

    private val expiryWarned = java.util.Collections.synchronizedSet(HashSet<String>())

    private fun warnIfExpiring(id: String, name: String, a: PlaylistAccount) {
        if (!a.expiringSoon() || !expiryWarned.add(id)) return
        val days = a.daysLeft() ?: return
        com.nuvio.tv.livetv.record.LiveTvNotice.show(
            when {
                a.expiresAtMs <= System.currentTimeMillis() -> "\"$name\" has expired"
                days == 0L -> "\"$name\" expires today"
                days == 1L -> "\"$name\" expires tomorrow"
                else -> "\"$name\" expires in $days days"
            }
        )
    }

    /**
     * An M3U link from an Xtream provider (…/get.php?username=…&password=…): the same server's
     * player_api.php has the account's expiry date and connections.
     */
    private suspend fun refreshM3uAccount(pl: PlaylistSource) = withContext(Dispatchers.IO) {
        val api = m3uAccountUrl(pl.url) ?: return@withContext
        runCatching {
            val ui = JSONObject(getText(api, pl.userAgent.ifBlank { DEFAULT_UA })).optJSONObject("user_info")
                ?: return@runCatching
            accountOf(ui)?.let { saveAccount(pl, it) }
        }
    }

    private fun m3uAccountUrl(url: String): String? = runCatching {
        val u = java.net.URI(url.trim())
        if (u.path?.endsWith("get.php", ignoreCase = true) != true) return@runCatching null
        val q = (u.rawQuery ?: return@runCatching null).split('&')
            .associate { it.substringBefore('=').lowercase() to it.substringAfter('=', "") }
        val user = q["username"]?.takeIf { it.isNotBlank() } ?: return@runCatching null
        val pass = q["password"] ?: return@runCatching null
        "${u.scheme}://${u.rawAuthority}/player_api.php?username=$user&password=$pass"
    }.getOrNull()

    private fun getText(url: String, userAgent: String): String {
        val request = Request.Builder().url(url).header("User-Agent", userAgent.ifBlank { DEFAULT_UA }).build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error(httpError(response.code))
            return response.body?.string() ?: error("Empty response")
        }
    }

    /** Plain-English reasons for the HTTP errors people actually hit. */
    private fun httpError(code: Int): String = when (code) {
        401, 403 -> "HTTP $code: the provider refused the request (wrong login, or it blocks this app; try setting a user agent)"
        404 -> "HTTP 404: nothing at that address (check the server, port and link)"
        429 -> "HTTP 429: too many requests, try again in a few minutes"
        // Not standard codes: Xtream panels use these when an account is over its connection
        // limit, expired, or blocked for the moment.
        456, 458, 461 -> "HTTP $code: the provider refused this login for now (too many connections, expired, or blocked). Close other apps using it and try again later."
        502, 503, 504, 520, 521, 522, 523, 524 -> "HTTP $code: the provider's server didn't respond, try again later"
        884 -> "HTTP 884: the provider blocked this app (try setting a user agent)"
        else -> "HTTP $code"
    }

    /** A zip stream at the fastest setting: a TV box's processor matters more than the last few MB. */
    private fun fastGzip(out: java.io.OutputStream): java.io.OutputStream =
        object : java.util.zip.GZIPOutputStream(java.io.BufferedOutputStream(out, 64 * 1024), 64 * 1024) {
            init { def.setLevel(java.util.zip.Deflater.BEST_SPEED) }
        }

    /**
     * Zips a saved guide or playlist that isn't zipped yet. Its "last changed" stamp is kept, so
     * this doesn't count as new content (the saved guide is read again once, as its size changed).
     */
    private fun zipInPlace(file: File) {
        runCatching {
            if (!file.exists() || file.length() < 1024 * 1024) return
            val zipped = file.inputStream().use { val a = it.read(); val b = it.read(); a == 0x1f && b == 0x8b }
            if (zipped) return
            val tmp = File(file.parentFile, file.name + ".zip.tmp")
            file.inputStream().use { input -> fastGzip(tmp.outputStream()).use { out -> input.copyTo(out, 64 * 1024) } }
            val modified = file.lastModified()
            if (!stampFile(file).exists()) markChanged(file)
            if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
            file.setLastModified(modified)
            LIVE_REPORT.add("Saved \"${file.name}\" zipped to save space")
        }.onFailure { Log.w(TAG, "Couldn't zip ${file.name}", it) }
    }

    private fun openMaybeGzip(file: File, onProgress: ((Long) -> Unit)? = null): InputStream {
        val raw: InputStream = if (onProgress == null) file.inputStream() else ProgressInputStream(file.inputStream(), onProgress)
        val input = BufferedInputStream(raw, 64 * 1024)
        input.mark(2)
        val b1 = input.read()
        val b2 = input.read()
        input.reset()
        return if (b1 == 0x1f && b2 == 0x8b) BufferedInputStream(GZIPInputStream(input, 64 * 1024)) else input
    }

    private fun sizeLabel(bytes: Long): String = when {
        bytes >= 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f GB", bytes / (1024.0 * 1024 * 1024))
        bytes >= 1024L * 1024 -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024))
        else -> "${bytes / 1024} KB"
    }

    /** Counts what's been read from a file, for "Reading guide… 45%". */
    private class ProgressInputStream(inner: InputStream, private val onProgress: (Long) -> Unit) : java.io.FilterInputStream(inner) {
        private var done = 0L
        override fun read(): Int = super.read().also { if (it >= 0) { done++; onProgress(done) } }
        override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) { done += it; onProgress(done) } }
        override fun skip(n: Long): Long = super.skip(n).also { done += it }
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)

    companion object {
        private const val TAG = "LiveTvRepository"
        private const val HOUR = 60L * 60L * 1000L
        /** Extra guide hours read ahead, so the window moves along a few times a day, not constantly. */
        /** The most channels of one group whose listings are loaded for every day ahead. */
        private const val MAX_FULL_RANGE_CHANNELS = 400
        // Hours read ahead of what's asked for (each read only adds the hours not loaded yet).
        private const val RANGE_SLACK_MS = 6 * HOUR
        private const val GUIDE_CACHE_VERSION = 1
        private const val CHANNELS_CACHE_VERSION = 6
        private const val MAX_SAVED_LISTINGS = 300_000
        /** Titles guides use when they have no real listing. */
        private val PLACEHOLDER_TITLES = Regex(
            """(programming|program|programme|no information|no info|no program information|no programme information|""" +
                """to be announced|tba|tbd|n/?a|off air|no data|no epg|not available|information not available|""" +
                """regular programming|scheduled programming|paid programming|coming soon)\.?"""
        )
        private val VOD_PATH = Regex("""/(movie|movies|series|vod)/""", RegexOption.IGNORE_CASE)
        private val VOD_EXT = Regex("""\.(mp4|mkv|avi|mov|wmv|m4v|webm|flv)(\?|$)""", RegexOption.IGNORE_CASE)

        /** A movie or episode in an M3U (by its link), not a live channel. */
        fun isVodEntry(url: String): Boolean = VOD_PATH.containsMatchIn(url) || VOD_EXT.containsMatchIn(url)

        /** "Programming", "No information", "To Be Announced"… (no real show to show a poster for). */
        fun isPlaceholderTitle(title: String): Boolean = PLACEHOLDER_TITLES.matches(title.trim().lowercase())

        const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 12; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

        private val qualityTokens = Regex("""\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|h264|1080p|720p|backup|raw)\b""")
        private val prefixToken = Regex("""^[a-z]{2,3}\s*[:|]\s*""")
        private val bracketed = Regex("""\[.*?]|\(.*?\)""")

        private const val SOURCE_LISTS_VERSION = 1

        internal fun normalize(name: String): String {
            var n = name.lowercase().trim()
            n = n.replace(prefixToken, "")
            n = n.replace(bracketed, " ")
            n = n.replace(qualityTokens, " ")
            return n.filter { it.isLetterOrDigit() }
        }
    }
}
